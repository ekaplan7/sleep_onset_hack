"""Smooth-Encoder-Fast3N: lean + embed + 3-head GBM, numpy tree-traversal inference.

The full encoder (Smooth-Encoder-NP, 45.71) broke the ceiling but timed out on
the server (~7 ms/window). This keeps the thing that mattered -- the learned
raw-signal embedding -- but trims everything else for the compute budget:
  * LEAN hand features (bands, 1-range aperiodic, entropy/edge, Hjorth, one
    broadband shape) -- ~0.5 ms, no cross-channel, no heavy discriminators.
  * SMALL 3-layer encoder -> ~0.6 ms embedding.
  * SINGLE bin-weighted GBM head (no near-specialist / classifier).
  * EMA smoothing + countdown.
Target ~2 ms/window, near aperiodic_weighted's confirmed-safe 1.8 ms.

Training uses torch (offline); inference is pure numpy (BN folded into convs),
with a torch-vs-numpy equivalence check in fit. Channel-count robust.
"""

import joblib
import numpy as np

from sklearn.ensemble import HistGradientBoostingRegressor, HistGradientBoostingClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from benchmark_utils.base_solver import CompetSolver
from benchmark_utils.data import to_numpy

BANDS = {"delta": (0.5, 4.0), "theta": (4.0, 8.0), "alpha": (8.0, 12.0),
         "sigma": (12.0, 16.0), "beta": (16.0, 30.0)}
FIT_LO, FIT_HI = 2.0, 40.0
EPS = 1e-8
CAP = 600.0
BIN_EDGES = np.array([0.0, 40.0, 90.0, 300.0, 600.0])
BIN_WEIGHTS = np.array([10.0, 5.0, 3.0, 1.0])
STEP = 5.0
A_FAST = 1.0 - 0.5 ** (1.0 / 6.0)
A_SLOW = 1.0 - 0.5 ** (1.0 / 24.0)
ALPHA = 0.4
NEAR_FIT = 90.0
IMM_T = 40.0
NCHAN = 4
# 3-layer encoder (fast, ~4.4 ms); strengthened via training (dropout/patience/epochs)
ENC_CH = [16, 24, 16]
ENC_K = [7, 5, 5]
ENC_S = [2, 2, 2]
ENC_P = [3, 2, 2]
EMB = ENC_CH[-1]
EPOCHS = 120
LR = 2e-3
BATCH = 256

_CACHE = {}


def _const(T, sf):
    key = (int(T), float(sf))
    c = _CACHE.get(key)
    if c is not None:
        return c
    T = int(T); sf = float(sf)
    n = np.arange(T)
    hann = (0.5 - 0.5 * np.cos(2.0 * np.pi * n / T)).astype(np.float32)
    freqs = np.fft.rfftfreq(T, d=1.0 / sf)
    tmask = (freqs >= 1.0) & (freqs <= 40.0)
    bm = {k: ((freqs >= lo) & (freqs < hi)) for k, (lo, hi) in BANDS.items()}
    fm = (freqs >= FIT_LO) & (freqs <= FIT_HI)
    lf = np.log10(np.clip(freqs[fm], EPS, None)); lfc = lf - lf.mean()
    bb = (freqs >= 1.0) & (freqs <= 40.0)
    c = dict(hann=hann, freqs=freqs, tmask=tmask, bm=bm, fm=fm, lfc=lfc,
             lfcss=max(float((lfc ** 2).sum()), EPS), lfmean=float(lf.mean()),
             fb=freqs[tmask], bb=bb)
    _CACHE[key] = c
    return c


def _fix_channels(X, n=NCHAN):
    C = X.shape[1]
    if C == n:
        return X
    if C > n:
        return X[:, :n]
    reps = int(np.ceil(n / C))
    return np.tile(X, (1, reps, 1))[:, :n]


def compute(X, sfreq):
    """lean hand features (B,C*20) + tracked (B,5) + channel-fixed raw (B,4,T)."""
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    c = _const(T, sfreq)
    freqs = c["freqs"]
    xw = (X - X.mean(-1, keepdims=True)) * c["hann"]
    spec = np.fft.rfft(xw, axis=-1)
    psd = spec.real ** 2 + spec.imag ** 2
    tmask = c["tmask"]
    total = np.clip(psd[..., tmask].sum(-1), EPS, None)
    bp = {}
    feats = []
    for k in BANDS:
        p = np.clip(psd[..., c["bm"][k]].sum(-1), EPS, None); bp[k] = p; feats.append(np.log(p))
    for k in BANDS:
        feats.append(bp[k] / total)
    feats.append(bp["delta"] / bp["beta"])
    feats.append((bp["delta"] + bp["theta"]) / (bp["alpha"] + bp["beta"]))
    ly = np.log10(np.clip(psd[..., c["fm"]], EPS, None))
    ly_c = ly - ly.mean(-1, keepdims=True)
    slope = (ly_c * c["lfc"]).sum(-1) / c["lfcss"]
    exponent = -slope; offset = ly.mean(-1) - slope * c["lfmean"]
    feats.append(exponent); feats.append(offset)
    p_b = psd[..., tmask]; f_b = c["fb"]
    tot = np.clip(p_b.sum(-1, keepdims=True), EPS, None); pn = p_b / tot
    feats.append(-(pn * np.log(pn + EPS)).sum(-1))
    cum = np.cumsum(p_b, -1) / tot
    feats.append(f_b[np.clip((cum < 0.95).sum(-1), 0, f_b.size - 1)])
    d1 = np.diff(X, axis=-1); d2 = np.diff(d1, axis=-1)
    v0 = np.clip(X.var(-1), EPS, None); v1 = np.clip(d1.var(-1), EPS, None); v2 = np.clip(d2.var(-1), EPS, None)
    mob = np.sqrt(v1 / v0)
    feats.append(mob); feats.append(np.sqrt(v2 / v1) / np.clip(mob, EPS, None))
    Xd = X - X.mean(-1, keepdims=True); Sp = np.fft.rfft(Xd, axis=-1)
    s = np.fft.irfft(Sp * c["bb"], n=T, axis=-1)
    mu = s.mean(-1, keepdims=True); dd0 = s - mu
    sk = (dd0 ** 3).mean(-1) / ((dd0 ** 2).mean(-1) ** 1.5 + EPS)
    ll = np.abs(np.diff(s, axis=-1)).sum(-1) / (np.clip(s.std(-1), EPS, None) * T)
    feats.append(sk); feats.append(ll)
    out = np.nan_to_num(np.stack(feats, -1), nan=0.0, posinf=0.0, neginf=0.0).reshape(B, -1)
    tracked = np.stack([exponent.mean(1), (bp["sigma"] / total).mean(1),
                        np.log(bp["delta"] / bp["beta"]).mean(1),
                        (bp["alpha"] / total).mean(1), np.log(total).mean(1)], axis=1)
    tracked = np.nan_to_num(tracked, nan=0.0, posinf=0.0, neginf=0.0)
    return out, tracked, X


CROSS_BANDS = [(0.5, 4.0), (4.0, 8.0), (8.0, 12.0), (12.0, 16.0), (1.0, 40.0)]
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


def crosschan(X, sfreq):
    """Inter-channel band-limited correlation + L/R power asymmetry (B,25)."""
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    freqs = np.fft.rfftfreq(T, d=1.0 / float(sfreq))
    Xd = X - X.mean(-1, keepdims=True)
    Sp = np.fft.rfft(Xd, axis=-1); psd = Sp.real ** 2 + Sp.imag ** 2
    feats = []
    for lo, hi in CROSS_BANDS:
        mm = (freqs >= lo) & (freqs < hi)
        xb = np.fft.irfft(Sp * mm, n=T, axis=-1)
        xc = xb - xb.mean(-1, keepdims=True)
        xn = xc / np.clip(xc.std(-1, keepdims=True), EPS, None)
        Cmat = np.matmul(xn, xn.transpose(0, 2, 1)) / T
        cp = np.stack([Cmat[:, i, j] for i, j in PAIRS], -1)
        p = np.clip(psd[..., mm].sum(-1), EPS, None)
        feats.append(cp.mean(-1, keepdims=True))
        feats.append(Cmat[:, 1, 2:3]); feats.append(Cmat[:, 0, 3:4])
        feats.append(np.log(p[:, 1:2] / p[:, 2:3])); feats.append(np.log(p[:, 0:1] / p[:, 3:4]))
    return np.nan_to_num(np.concatenate(feats, -1), nan=0.0, posinf=0.0, neginf=0.0)


def _best_const(y):
    gr = np.arange(0.0, 600.01, 2.0)
    idx = np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)
    ne = [b for b in range(4) if np.any(idx == b)]
    s = [(BIN_WEIGHTS[ne] * np.array([np.abs(cc - y)[idx == b].mean() for b in ne])).sum()
         / BIN_WEIGHTS[ne].sum() for cc in gr]
    return float(gr[int(np.argmin(s))])


def _conv_bt(x, W, b, stride, pad):
    """Batched 1D conv via im2col: x:(G,Cin,T) -> (G,Cout,Tout). ONE matmul per
    layer (not k per-tap ops). Symmetric padding to match torch Conv1d(padding)."""
    G, Cin, T = x.shape; Cout, _, k = W.shape
    xp = np.pad(x, ((0, 0), (0, 0), (pad, pad)))
    Tout = (xp.shape[2] - k) // stride + 1
    idx = np.arange(Tout)[:, None] * stride + np.arange(k)[None, :]   # (Tout,k)
    cols = xp[:, :, idx].transpose(0, 1, 3, 2).reshape(G, Cin * k, Tout)  # (G,Cin*k,Tout)
    Wm = W.reshape(Cout, Cin * k)
    out = np.einsum('oc,gct->got', Wm, cols, optimize=True)
    return out + b[None, :, None]


def _np_embed(Xb, encW, chunk=512):
    """Xb:(B,4,T) -> (B,4*EMB). im2col conv, chunked over B to bound memory
    (the all-at-once version OOMs on the full training set)."""
    B = Xb.shape[0]
    outs = []
    for s in range(0, B, chunk):
        xb = Xb[s:s + chunk]
        g = xb.reshape(-1, 1, Xb.shape[-1]).astype(np.float64)
        g = (g - g.mean(-1, keepdims=True)) / (g.std(-1, keepdims=True) + 1e-6)
        for li in range(len(ENC_CH)):
            g = np.maximum(_conv_bt(g, encW[f"c{li}_w"], encW[f"c{li}_b"], ENC_S[li], ENC_P[li]), 0.0)
        outs.append(g.mean(-1).reshape(xb.shape[0], NCHAN * EMB))
    return np.concatenate(outs, 0)


def _export_gbm(pipe):
    """Extract scaler + HGBR/HGBClassifier trees so predict runs in numpy
    (sklearn.predict has ~2ms B=1 overhead; traversal is ~0.4ms, exact match)."""
    sc = pipe.steps[0][1]; est = pipe.steps[-1][1]
    base = float(np.ravel(est._baseline_prediction)[0])
    trees = []
    for it in est._predictors:
        nd = it[0].nodes
        trees.append((nd['feature_idx'].astype(np.int32), nd['num_threshold'].astype(np.float64),
                      nd['left'].astype(np.int32), nd['right'].astype(np.int32),
                      nd['is_leaf'].astype(np.uint8), nd['value'].astype(np.float64)))
    return {"mean": sc.mean_.astype(np.float64), "scale": sc.scale_.astype(np.float64),
            "base": base, "trees": trees}


def _gbm_raw(x, G):
    xs = (x - G["mean"]) / G["scale"]; tot = G["base"]
    for (fi, th, lf, rt, leaf, val) in G["trees"]:
        n = 0
        while not leaf[n]:
            n = lf[n] if xs[fi[n]] <= th[n] else rt[n]
        tot += val[n]
    return tot


class EncFast:
    def __init__(self, meta):
        self.sfreq = float(meta["sfreq"]); self.device = meta.get("device", "cpu")
        self.encW = None; self.pipe = None; self.pipe_near = None; self.clf = None
        self.Greg = None; self.Gnear = None; self.Gclf = None
        self._ef = None; self._es = None; self._cd = None

    def reset_state(self):
        self._ef = None; self._es = None; self._cd = None

    def _gather(self, loader):
        hand, trk, raw, rid, ons, Y = [], [], [], [], [], []
        for X, y, info in loader:
            o, t, Xr = compute(X, self.sfreq)
            hand.append(o); trk.append(t); raw.append(Xr)
            rid.append(to_numpy(info["record_id"]).reshape(-1))
            ons.append(to_numpy(info["onset"]).reshape(-1)); Y.append(to_numpy(y).ravel())
        return (np.concatenate(hand), np.concatenate(trk), np.concatenate(raw),
                np.concatenate(rid).astype(np.int64), np.concatenate(ons).astype(np.float64),
                np.concatenate(Y))

    def _ema_assemble(self, fused, trk, rid, ons, y):
        first = {}
        for i in range(len(y)):
            k = (int(rid[i]), round(float(ons[i]), 3))
            if k not in first:
                first[k] = i
        smap = {}
        for r in np.unique(rid):
            os_r = sorted({round(float(o), 3) for o in ons[rid == r]})
            ef = es = None; prev = None
            for o in os_r:
                t = trk[first[(int(r), o)]]
                if prev is None or abs(o - (prev + STEP)) > 1e-6:
                    ef = t.copy(); es = t.copy()
                else:
                    ef = A_FAST * t + (1 - A_FAST) * ef
                    es = A_SLOW * t + (1 - A_SLOW) * es
                smap[(int(r), o)] = np.concatenate([ef, es]); prev = o
        S = np.stack([smap[(int(rid[i]), round(float(ons[i]), 3))] for i in range(len(y))])
        return np.concatenate([fused, S], axis=1)

    def _train_encoder(self, raw, y, rid):
        import torch
        import torch.nn as nn
        torch.manual_seed(0)

        class Enc(nn.Module):
            def __init__(self):
                super().__init__()
                layers = []; cin = 1
                for co, k, s, p in zip(ENC_CH, ENC_K, ENC_S, ENC_P):
                    layers += [nn.Conv1d(cin, co, k, stride=s, padding=p, bias=False), nn.BatchNorm1d(co), nn.ReLU()]
                    cin = co
                self.body = nn.Sequential(*layers)
            def forward(self, x):
                return self.body(x).mean(-1)

        class Net(nn.Module):
            def __init__(self):
                super().__init__()
                self.enc = Enc(); self.drop = nn.Dropout(0.25)
                self.head = nn.Sequential(nn.Linear(NCHAN * EMB, 64), nn.ReLU(), nn.Dropout(0.25), nn.Linear(64, 1))
            def forward(self, x4):
                N = x4.shape[0]
                z = x4.reshape(N * NCHAN, 1, x4.shape[-1])
                m = z.mean(-1, keepdim=True); sd = z.std(-1, keepdim=True).clamp_min(1e-6)
                e = self.drop(self.enc((z - m) / sd).reshape(N, NCHAN * EMB))
                return self.head(e)[:, 0]

        net = Net()
        opt = torch.optim.Adam(net.parameters(), lr=LR, weight_decay=1e-4)
        Xt = torch.tensor(raw.astype(np.float32)); yt = torch.tensor(y.astype(np.float32))
        sw = torch.tensor(BIN_WEIGHTS[np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)].astype(np.float32))
        rng = np.random.default_rng(0)
        urec = np.unique(rid); rng.shuffle(urec)
        nval = max(1, int(0.15 * len(urec))); valrec = set(urec[:nval].tolist())
        vmask = np.array([r in valrec for r in rid])
        tr_idx = np.where(~vmask)[0]; va_idx = np.where(vmask)[0]
        best = {"val": np.inf, "state": None}; bad = 0
        for ep in range(EPOCHS):
            net.train(); perm = rng.permutation(tr_idx)
            for s in range(0, len(perm), BATCH):
                idx = perm[s:s + BATCH]; opt.zero_grad()
                loss = (sw[idx] * (net(Xt[idx]).clamp(0, CAP) - yt[idx]).abs()).mean()
                loss.backward(); opt.step()
            net.eval()
            with torch.no_grad():
                vloss = float((sw[va_idx] * (net(Xt[va_idx]).clamp(0, CAP) - yt[va_idx]).abs()).mean())
            if vloss < best["val"] - 1e-3:
                best = {"val": vloss, "state": {k: v.clone() for k, v in net.state_dict().items()}}; bad = 0
            else:
                bad += 1
            if ep % 15 == 0 or ep == EPOCHS - 1:
                print(f"[enc] epoch {ep:3d}  val-wL1 {vloss:.2f}")
            if bad >= 15:
                print(f"[enc] early stop @ {ep} (best val {best['val']:.2f})")
                break
        if best["state"] is not None:
            net.load_state_dict(best["state"])
        net.eval()
        encW = {}; mods = list(net.enc.body); li = 0
        for i in range(0, len(mods), 3):
            conv = mods[i]; bn = mods[i + 1]
            Wc = conv.weight.detach().numpy().astype(np.float64)
            g = bn.weight.detach().numpy().astype(np.float64); be = bn.bias.detach().numpy().astype(np.float64)
            mu = bn.running_mean.detach().numpy().astype(np.float64); var = bn.running_var.detach().numpy().astype(np.float64)
            scale = g / np.sqrt(var + bn.eps)
            encW[f"c{li}_w"] = Wc * scale[:, None, None]; encW[f"c{li}_b"] = be - scale * mu; li += 1
        self.encW = encW
        return net

    def fit(self, loader):
        hand, trk, raw, rid, ons, y = self._gather(loader)
        net = self._train_encoder(raw, y, rid)
        import torch
        with torch.no_grad():
            idx = np.arange(min(64, len(raw))); z = torch.tensor(raw[idx].astype(np.float32))
            N = z.shape[0]; zz = z.reshape(N * NCHAN, 1, z.shape[-1])
            m = zz.mean(-1, keepdim=True); sd = zz.std(-1, keepdim=True).clamp_min(1e-6)
            te = net.enc((zz - m) / sd).reshape(N, NCHAN * EMB).numpy()
        print(f"[enc] torch-vs-numpy embed max|diff| = {np.abs(te - _np_embed(raw[idx], self.encW)).max():.3e}")
        E = _np_embed(raw, self.encW)
        cross = crosschan(raw, self.sfreq)
        Xf = self._ema_assemble(np.concatenate([hand, cross, E], axis=1), trk, rid, ons, y)
        print(f"[enc-fast] fused dim = {Xf.shape[1]} (hand {hand.shape[1]} + cross {cross.shape[1]} + emb {E.shape[1]} + ema 10)")
        sw = BIN_WEIGHTS[np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)]
        rng = np.random.default_rng(33); urec = np.unique(rid); rng.shuffle(urec)
        ho_rec = set(urec[:max(1, int(0.2 * len(urec)))].tolist())
        ho = np.array([i for i in range(len(y)) if int(rid[i]) in ho_rec])
        tr = np.array([i for i in range(len(y)) if int(rid[i]) not in ho_rec])
        dg = Pipeline([("s", StandardScaler()), ("r", HistGradientBoostingRegressor(loss="absolute_error"))])
        dg.fit(Xf[tr], y[tr], r__sample_weight=sw[tr])
        c0 = _best_const(y[tr]); yh = y[ho]
        pg = np.clip(dg.predict(Xf[ho]), 0, 600); bi = np.clip(np.digitize(yh, BIN_EDGES[1:-1]), 0, 3)
        print(f"[enc-fast per-bin | recording-level holdout] c={c0:.1f}")
        for b, lab in enumerate(["[0,40)", "[40,90)", "[90,300)", "[300,600]"]):
            mk = bi == b
            if mk.any():
                print(f"{lab:12s} GBM {np.abs(pg[mk]-yh[mk]).mean():6.1f}  const {np.abs(c0-yh[mk]).mean():6.1f}")
        self.pipe = Pipeline([("s", StandardScaler()),
                              ("r", HistGradientBoostingRegressor(loss="absolute_error", max_iter=60))])
        self.pipe.fit(Xf, y, r__sample_weight=sw)
        mnear = y < NEAR_FIT
        self.pipe_near = Pipeline([("s", StandardScaler()),
                                   ("r", HistGradientBoostingRegressor(loss="absolute_error", max_iter=60))])
        self.pipe_near.fit(Xf[mnear], y[mnear], r__sample_weight=sw[mnear])
        lab = (y < IMM_T).astype(int)
        npos = max(int(lab.sum()), 1); nneg = max(int((1 - lab).sum()), 1)
        cw = np.where(lab == 1, len(lab) / (2.0 * npos), len(lab) / (2.0 * nneg))
        self.clf = Pipeline([("s", StandardScaler()), ("c", HistGradientBoostingClassifier(max_iter=60))])
        self.clf.fit(Xf, lab, c__sample_weight=cw)
        # export trees -> numpy, validate traversal == sklearn
        self.Greg = _export_gbm(self.pipe); self.Gnear = _export_gbm(self.pipe_near); self.Gclf = _export_gbm(self.clf)
        chk = Xf[:200]
        d_reg = np.abs(np.array([_gbm_raw(chk[i], self.Greg) for i in range(len(chk))]) - self.pipe.predict(chk)).max()
        d_clf = np.abs(1/(1+np.exp(-np.array([_gbm_raw(chk[i], self.Gclf) for i in range(len(chk))]))) - self.clf.predict_proba(chk)[:,1]).max()
        print(f"[gbm] numpy-traversal vs sklearn  reg={d_reg:.2e}  clf={d_clf:.2e}  (want ~0)")
        return self

    def predict(self, X):
        o, trk, Xr = compute(X, self.sfreq)
        E = _np_embed(Xr, self.encW)
        xc = crosschan(Xr, self.sfreq)
        rows = []
        for i in range(len(o)):
            t = trk[i]
            if self._ef is None:
                self._ef = t.copy(); self._es = t.copy()
            else:
                self._ef = A_FAST * t + (1 - A_FAST) * self._ef
                self._es = A_SLOW * t + (1 - A_SLOW) * self._es
            rows.append(np.concatenate([o[i], xc[i], E[i], self._ef, self._es]))
        out = np.empty(len(rows))
        for i in range(len(rows)):
            r = rows[i]
            p_reg = min(max(_gbm_raw(r, self.Greg), 0.0), CAP)
            p_near = min(max(_gbm_raw(r, self.Gnear), 0.0), CAP)
            p_imm = 1.0 / (1.0 + np.exp(-_gbm_raw(r, self.Gclf)))
            out[i] = p_imm * p_near + (1.0 - p_imm) * p_reg
        raw = np.clip(out, 0.0, CAP)
        out = np.empty_like(raw)
        for i in range(len(raw)):
            est = raw[i] if self._cd is None else ALPHA * raw[i] + (1 - ALPHA) * max(self._cd - STEP, 0.0)
            est = min(max(est, 0.0), CAP); self._cd = est; out[i] = est
        return out


class Solver(CompetSolver):
    name = "Smooth-Encoder-Fast3NX"
    requirements = []

    def load_model(self, meta):
        mdl = EncFast(meta)
        w = meta["submission_dir"] / "weights.joblib"
        if w.exists():
            ck = joblib.load(w); mdl.encW = ck["encW"]
            mdl.Greg = ck["Greg"]; mdl.Gnear = ck["Gnear"]; mdl.Gclf = ck["Gclf"]
        elif self.train_loader is None:
            raise FileNotFoundError("Smooth-Encoder-Fast3NX needs weights.joblib; train with training=True.")
        return mdl

    def fit(self, model, loader):
        model.fit(loader)

    def save_model(self, model, path):
        joblib.dump({"encW": model.encW, "Greg": model.Greg, "Gnear": model.Gnear, "Gclf": model.Gclf}, path / "weights.joblib")
