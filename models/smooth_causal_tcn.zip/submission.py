"""Smooth-Causal-TCN: encoder+GBM (Fast3NX) blended with a causal TCN over the
window trajectory, with an elapsed-time feature. Pure-numpy streaming inference.

Rationale (what the leaderboard's "6 causal TCN + 5 GBM" shape is doing, done
right this time):
  * A SINGLE 5-s window caps per-window accuracy (~45.7). The TRAJECTORY of the
    windows -- aperiodic slope steepening, alpha dropout, spindle/K-complex
    onset over minutes -- carries the rest. Our EMA/countdown only crudely
    approximates that trajectory; a causal TCN models it.
  * The TCN here consumes the full per-window vector INCLUDING the learned
    encoder embedding (the thing that broke the ceiling) PLUS an explicit
    elapsed-time-since-reset feature (seconds the recording has been running,
    counted from reset_state -- a direct sleep-latency prior).
  * The blend partner is the STRONG Fast3NX 3-head GBM (hand+cross+emb+ema),
    i.e. the confirmed 45.98 model -- so W_TCN=0 reproduces 45.98 exactly and
    the blend can only add. W_TCN is tuned on a recording-level holdout against
    the real W-bMAE metric, so we KNOW whether the TCN helps before submitting.
  * final = W_TCN*tcn + (1-W_TCN)*gbm3head, then the countdown filter.

Why the previous TCN (Smooth-TCN-NP, 50.79) underperformed and is fixed here:
  (1) it fed the TCN only tabular features (no encoder embedding); fixed.
  (2) its GBM partner had no embedding (weak); now the strong Fast3NX GBM.
  (3) it used the TCN only in the FAR field and pure-GBM in the near bins --
      exactly backwards for a 10x/5x-weighted near region; now a single tuned
      blend across all bins.
  (4) no elapsed-time feature; added.
  (5) BatchNorm-on-sequence pathology risk -> channel LayerNorm (ports exactly).

TRAINING (fit) uses torch offline; it exports the TCN + encoder to plain numpy
and prints torch-vs-numpy equivalence checks (full-sequence AND O(1) streaming)
plus the holdout W-bMAE for each blend weight. INFERENCE (predict) is pure
numpy: an O(1)-per-window streaming causal TCN (per-layer ring buffers), the
numpy encoder (BN folded), and numpy GBM tree-traversal. Channel-count robust.
numpy + sklearn + joblib (+ torch only inside fit).
"""

import joblib
import numpy as np

from sklearn.ensemble import HistGradientBoostingRegressor, HistGradientBoostingClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from benchmark_utils.base_solver import CompetSolver
from benchmark_utils.data import to_numpy

BANDS = {"delta": (0.5, 4.0), "theta": (4.0, 8.0), "alpha": (8.0, 12.0),
         "sigma": (12.0, 16.0), "beta": (16.0, 30.0)}
FIT_LO, FIT_HI = 2.0, 40.0
EPS = 1e-8
CAP = 600.0
BIN_EDGES = np.array([0.0, 40.0, 90.0, 300.0, 600.0])
BIN_WEIGHTS = np.array([10.0, 5.0, 3.0, 1.0])
STEP = 5.0
A_FAST = 1.0 - 0.5 ** (1.0 / 6.0)
A_SLOW = 1.0 - 0.5 ** (1.0 / 24.0)
ALPHA = 0.4
NEAR_FIT = 90.0
IMM_T = 40.0
NCHAN = 4
# encoder (identical to Fast3NX / 45.98)
ENC_CH = [16, 24, 16]
ENC_K = [7, 5, 5]
ENC_S = [2, 2, 2]
ENC_P = [3, 2, 2]
EMB = ENC_CH[-1]
EPOCHS = 120
LR = 2e-3
BATCH = 256
# causal TCN
HID = 64
KERNEL = 3
DILATIONS = [1, 2, 4, 8, 16, 32]
RF = 1 + sum((KERNEL - 1) * d for d in DILATIONS)   # receptive field (windows)
LN_EPS = 1e-5
TCN_EPOCHS = 220
TCN_LR = 3e-3
TCN_WD = 1e-4
TCN_DROP = 0.2
TCN_BATCH = 16
TCN_PATIENCE = 22
W_GRID = [0.0, 0.2, 0.35, 0.5, 0.65, 0.8]

_CACHE = {}


def _const(T, sf):
    key = (int(T), float(sf))
    c = _CACHE.get(key)
    if c is not None:
        return c
    T = int(T); sf = float(sf)
    n = np.arange(T)
    hann = (0.5 - 0.5 * np.cos(2.0 * np.pi * n / T)).astype(np.float32)
    freqs = np.fft.rfftfreq(T, d=1.0 / sf)
    tmask = (freqs >= 1.0) & (freqs <= 40.0)
    bm = {k: ((freqs >= lo) & (freqs < hi)) for k, (lo, hi) in BANDS.items()}
    fm = (freqs >= FIT_LO) & (freqs <= FIT_HI)
    lf = np.log10(np.clip(freqs[fm], EPS, None)); lfc = lf - lf.mean()
    bb = (freqs >= 1.0) & (freqs <= 40.0)
    c = dict(hann=hann, freqs=freqs, tmask=tmask, bm=bm, fm=fm, lfc=lfc,
             lfcss=max(float((lfc ** 2).sum()), EPS), lfmean=float(lf.mean()),
             fb=freqs[tmask], bb=bb)
    _CACHE[key] = c
    return c


def _fix_channels(X, n=NCHAN):
    C = X.shape[1]
    if C == n:
        return X
    if C > n:
        return X[:, :n]
    reps = int(np.ceil(n / C))
    return np.tile(X, (1, reps, 1))[:, :n]


def compute(X, sfreq):
    """lean hand features (B,C*20) + tracked (B,5) + channel-fixed raw (B,4,T)."""
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    c = _const(T, sfreq)
    freqs = c["freqs"]
    xw = (X - X.mean(-1, keepdims=True)) * c["hann"]
    spec = np.fft.rfft(xw, axis=-1)
    psd = spec.real ** 2 + spec.imag ** 2
    tmask = c["tmask"]
    total = np.clip(psd[..., tmask].sum(-1), EPS, None)
    bp = {}
    feats = []
    for k in BANDS:
        p = np.clip(psd[..., c["bm"][k]].sum(-1), EPS, None); bp[k] = p; feats.append(np.log(p))
    for k in BANDS:
        feats.append(bp[k] / total)
    feats.append(bp["delta"] / bp["beta"])
    feats.append((bp["delta"] + bp["theta"]) / (bp["alpha"] + bp["beta"]))
    ly = np.log10(np.clip(psd[..., c["fm"]], EPS, None))
    ly_c = ly - ly.mean(-1, keepdims=True)
    slope = (ly_c * c["lfc"]).sum(-1) / c["lfcss"]
    exponent = -slope; offset = ly.mean(-1) - slope * c["lfmean"]
    feats.append(exponent); feats.append(offset)
    p_b = psd[..., tmask]; f_b = c["fb"]
    tot = np.clip(p_b.sum(-1, keepdims=True), EPS, None); pn = p_b / tot
    feats.append(-(pn * np.log(pn + EPS)).sum(-1))
    cum = np.cumsum(p_b, -1) / tot
    feats.append(f_b[np.clip((cum < 0.95).sum(-1), 0, f_b.size - 1)])
    d1 = np.diff(X, axis=-1); d2 = np.diff(d1, axis=-1)
    v0 = np.clip(X.var(-1), EPS, None); v1 = np.clip(d1.var(-1), EPS, None); v2 = np.clip(d2.var(-1), EPS, None)
    mob = np.sqrt(v1 / v0)
    feats.append(mob); feats.append(np.sqrt(v2 / v1) / np.clip(mob, EPS, None))
    Xd = X - X.mean(-1, keepdims=True); Sp = np.fft.rfft(Xd, axis=-1)
    s = np.fft.irfft(Sp * c["bb"], n=T, axis=-1)
    mu = s.mean(-1, keepdims=True); dd0 = s - mu
    sk = (dd0 ** 3).mean(-1) / ((dd0 ** 2).mean(-1) ** 1.5 + EPS)
    ll = np.abs(np.diff(s, axis=-1)).sum(-1) / (np.clip(s.std(-1), EPS, None) * T)
    feats.append(sk); feats.append(ll)
    out = np.nan_to_num(np.stack(feats, -1), nan=0.0, posinf=0.0, neginf=0.0).reshape(B, -1)
    tracked = np.stack([exponent.mean(1), (bp["sigma"] / total).mean(1),
                        np.log(bp["delta"] / bp["beta"]).mean(1),
                        (bp["alpha"] / total).mean(1), np.log(total).mean(1)], axis=1)
    tracked = np.nan_to_num(tracked, nan=0.0, posinf=0.0, neginf=0.0)
    return out, tracked, X


CROSS_BANDS = [(0.5, 4.0), (4.0, 8.0), (8.0, 12.0), (12.0, 16.0), (1.0, 40.0)]
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


def crosschan(X, sfreq):
    """Inter-channel band-limited correlation + L/R power asymmetry (B,25)."""
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    freqs = np.fft.rfftfreq(T, d=1.0 / float(sfreq))
    Xd = X - X.mean(-1, keepdims=True)
    Sp = np.fft.rfft(Xd, axis=-1); psd = Sp.real ** 2 + Sp.imag ** 2
    feats = []
    for lo, hi in CROSS_BANDS:
        mm = (freqs >= lo) & (freqs < hi)
        xb = np.fft.irfft(Sp * mm, n=T, axis=-1)
        xc = xb - xb.mean(-1, keepdims=True)
        xn = xc / np.clip(xc.std(-1, keepdims=True), EPS, None)
        Cmat = np.matmul(xn, xn.transpose(0, 2, 1)) / T
        cp = np.stack([Cmat[:, i, j] for i, j in PAIRS], -1)
        p = np.clip(psd[..., mm].sum(-1), EPS, None)
        feats.append(cp.mean(-1, keepdims=True))
        feats.append(Cmat[:, 1, 2:3]); feats.append(Cmat[:, 0, 3:4])
        feats.append(np.log(p[:, 1:2] / p[:, 2:3])); feats.append(np.log(p[:, 0:1] / p[:, 3:4]))
    return np.nan_to_num(np.concatenate(feats, -1), nan=0.0, posinf=0.0, neginf=0.0)


def _best_const(y):
    gr = np.arange(0.0, 600.01, 2.0)
    idx = np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)
    ne = [b for b in range(4) if np.any(idx == b)]
    s = [(BIN_WEIGHTS[ne] * np.array([np.abs(cc - y)[idx == b].mean() for b in ne])).sum()
         / BIN_WEIGHTS[ne].sum() for cc in gr]
    return float(gr[int(np.argmin(s))])


def _conv_bt(x, W, b, stride, pad):
    """Batched 1D conv via im2col: x:(G,Cin,T) -> (G,Cout,Tout). ONE matmul."""
    G, Cin, T = x.shape; Cout, _, k = W.shape
    xp = np.pad(x, ((0, 0), (0, 0), (pad, pad)))
    Tout = (xp.shape[2] - k) // stride + 1
    idx = np.arange(Tout)[:, None] * stride + np.arange(k)[None, :]
    cols = xp[:, :, idx].transpose(0, 1, 3, 2).reshape(G, Cin * k, Tout)
    Wm = W.reshape(Cout, Cin * k)
    out = np.einsum('oc,gct->got', Wm, cols, optimize=True)
    return out + b[None, :, None]


def _np_embed(Xb, encW, chunk=512):
    """Xb:(B,4,T) -> (B,4*EMB). im2col conv, chunked over B to bound memory."""
    B = Xb.shape[0]
    outs = []
    for s in range(0, B, chunk):
        xb = Xb[s:s + chunk]
        g = xb.reshape(-1, 1, Xb.shape[-1]).astype(np.float64)
        g = (g - g.mean(-1, keepdims=True)) / (g.std(-1, keepdims=True) + 1e-6)
        for li in range(len(ENC_CH)):
            g = np.maximum(_conv_bt(g, encW[f"c{li}_w"], encW[f"c{li}_b"], ENC_S[li], ENC_P[li]), 0.0)
        outs.append(g.mean(-1).reshape(xb.shape[0], NCHAN * EMB))
    return np.concatenate(outs, 0)


def _export_gbm(pipe):
    """Scaler + HGBR/HGBClassifier trees -> numpy (exact, ~0.4ms vs sklearn ~2ms)."""
    sc = pipe.steps[0][1]; est = pipe.steps[-1][1]
    base = float(np.ravel(est._baseline_prediction)[0])
    trees = []
    for it in est._predictors:
        nd = it[0].nodes
        trees.append((nd['feature_idx'].astype(np.int32), nd['num_threshold'].astype(np.float64),
                      nd['left'].astype(np.int32), nd['right'].astype(np.int32),
                      nd['is_leaf'].astype(np.uint8), nd['value'].astype(np.float64)))
    return {"mean": sc.mean_.astype(np.float64), "scale": sc.scale_.astype(np.float64),
            "base": base, "trees": trees}


def _gbm_raw(x, G):
    xs = (x - G["mean"]) / G["scale"]; tot = G["base"]
    for (fi, th, lf, rt, leaf, val) in G["trees"]:
        n = 0
        while not leaf[n]:
            n = lf[n] if xs[fi[n]] <= th[n] else rt[n]
        tot += val[n]
    return tot


# -------------------------- elapsed-time feature --------------------------
def _elapsed_feats(i):
    """2 features from the 0-based window index i (seconds since reset = i*STEP),
    matching train (position in sorted-onset sequence) and inference (counter)."""
    t = i * STEP
    return np.array([t, np.log1p(t)], dtype=np.float64)


# ------------------------- numpy causal TCN forwards ----------------------
def _ln_cols(M, g, b):
    """channel LayerNorm over axis 0: M:(HID,T) -> (HID,T)."""
    mu = M.mean(0, keepdims=True)
    var = M.var(0, keepdims=True)
    return (M - mu) / np.sqrt(var + LN_EPS) * g[:, None] + b[:, None]


def _np_tcn_full(Fseq, W):
    """Fseq:(F,T) standardized -> (T,) predictions, clipped to [0,CAP].
    Full-sequence reference forward (matches torch)."""
    h = np.maximum(W["in_w"] @ Fseq + W["in_b"][:, None], 0.0)   # (HID,T)
    T = Fseq.shape[1]
    for li, d in enumerate(DILATIONS):
        hp = np.pad(h, ((0, 0), ((KERNEL - 1) * d, 0)))
        conv = np.zeros((HID, T), dtype=np.float64)
        Wb = W[f"c{li}_w"]
        for j in range(KERNEL):
            conv += Wb[:, :, j] @ hp[:, j * d: j * d + T]
        conv += W[f"c{li}_b"][:, None]
        z = np.maximum(_ln_cols(conv, W[f"ln{li}_g"], W[f"ln{li}_b"]), 0.0)
        h = h + z
    y = W["out_w"] @ h + W["out_b"]
    return np.clip(y.ravel(), 0.0, CAP)


class _StreamTCN:
    """O(1)-per-window causal TCN: per-layer ring buffers of block inputs.
    step(x) returns the prediction at the current timestep, exactly matching
    _np_tcn_full at its last position."""

    def __init__(self, W):
        self.W = W
        self.reset()

    def reset(self):
        self.bufs = [[] for _ in DILATIONS]   # buf[li]: recent inputs to block li

    def step(self, x):
        W = self.W
        h = np.maximum(W["in_w"] @ x + W["in_b"], 0.0)   # (HID,) input to block 0
        for li, d in enumerate(DILATIONS):
            buf = self.bufs[li]
            buf.append(h)
            need = (KERNEL - 1) * d + 1
            if len(buf) > need:
                del buf[0]
            conv = W[f"c{li}_b"].copy()
            Wb = W[f"c{li}_w"]
            L = len(buf)
            for j in range(KERNEL):
                lag = (KERNEL - 1 - j) * d
                idx = L - 1 - lag
                if idx >= 0:
                    conv = conv + Wb[:, :, j] @ buf[idx]
            mu = conv.mean(); var = conv.var()
            z = (conv - mu) / np.sqrt(var + LN_EPS) * W[f"ln{li}_g"] + W[f"ln{li}_b"]
            z = np.maximum(z, 0.0)
            h = h + z
        y = float((W["out_w"] @ h + W["out_b"]).ravel()[0])
        return min(max(y, 0.0), CAP)


class CausalTCN:
    def __init__(self, meta):
        self.sfreq = float(meta["sfreq"]); self.device = meta.get("device", "cpu")
        self.encW = None
        self.Greg = None; self.Gnear = None; self.Gclf = None
        self.W = None; self.fmean = None; self.fstd = None; self.w_tcn = 0.0
        self._ef = None; self._es = None; self._cd = None; self._i = 0; self._stream = None

    def reset_state(self):
        self._ef = None; self._es = None; self._cd = None; self._i = 0
        if self.W is not None:
            if self._stream is None:
                self._stream = _StreamTCN(self.W)
            else:
                self._stream.reset()

    # ---------- shared feature assembly ----------
    def _gather(self, loader):
        hand, trk, raw, rid, ons, Y = [], [], [], [], [], []
        for X, y, info in loader:
            o, t, Xr = compute(X, self.sfreq)
            hand.append(o); trk.append(t); raw.append(Xr)
            rid.append(to_numpy(info["record_id"]).reshape(-1))
            ons.append(to_numpy(info["onset"]).reshape(-1)); Y.append(to_numpy(y).ravel())
        return (np.concatenate(hand), np.concatenate(trk), np.concatenate(raw),
                np.concatenate(rid).astype(np.int64), np.concatenate(ons).astype(np.float64),
                np.concatenate(Y))

    def _train_encoder(self, raw, y, rid, seed=0):
        import torch
        import torch.nn as nn
        torch.manual_seed(seed)

        class Enc(nn.Module):
            def __init__(self):
                super().__init__()
                layers = []; cin = 1
                for co, k, s, p in zip(ENC_CH, ENC_K, ENC_S, ENC_P):
                    layers += [nn.Conv1d(cin, co, k, stride=s, padding=p, bias=False), nn.BatchNorm1d(co), nn.ReLU()]
                    cin = co
                self.body = nn.Sequential(*layers)

            def forward(self, x):
                return self.body(x).mean(-1)

        class Net(nn.Module):
            def __init__(self):
                super().__init__()
                self.enc = Enc(); self.drop = nn.Dropout(0.25)
                self.head = nn.Sequential(nn.Linear(NCHAN * EMB, 64), nn.ReLU(), nn.Dropout(0.25), nn.Linear(64, 1))

            def forward(self, x4):
                N = x4.shape[0]
                z = x4.reshape(N * NCHAN, 1, x4.shape[-1])
                m = z.mean(-1, keepdim=True); sd = z.std(-1, keepdim=True).clamp_min(1e-6)
                e = self.drop(self.enc((z - m) / sd).reshape(N, NCHAN * EMB))
                return self.head(e)[:, 0]

        net = Net()
        opt = torch.optim.Adam(net.parameters(), lr=LR, weight_decay=1e-4)
        Xt = torch.tensor(raw.astype(np.float32)); yt = torch.tensor(y.astype(np.float32))
        sw = torch.tensor(BIN_WEIGHTS[np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)].astype(np.float32))
        rng = np.random.default_rng(seed)
        urec = np.unique(rid); rng.shuffle(urec)
        nval = max(1, int(0.15 * len(urec))); valrec = set(urec[:nval].tolist())
        vmask = np.array([r in valrec for r in rid])
        tr_idx = np.where(~vmask)[0]; va_idx = np.where(vmask)[0]
        best = {"val": np.inf, "state": None}; bad = 0
        for ep in range(EPOCHS):
            net.train(); perm = rng.permutation(tr_idx)
            for s in range(0, len(perm), BATCH):
                idx = perm[s:s + BATCH]; opt.zero_grad()
                loss = (sw[idx] * (net(Xt[idx]).clamp(0, CAP) - yt[idx]).abs()).mean()
                loss.backward(); opt.step()
            net.eval()
            with torch.no_grad():
                vloss = float((sw[va_idx] * (net(Xt[va_idx]).clamp(0, CAP) - yt[va_idx]).abs()).mean())
            if vloss < best["val"] - 1e-3:
                best = {"val": vloss, "state": {k: v.clone() for k, v in net.state_dict().items()}}; bad = 0
            else:
                bad += 1
            if ep % 30 == 0 or ep == EPOCHS - 1:
                print(f"[enc] epoch {ep:3d}  val-wL1 {vloss:.2f}")
            if bad >= 15:
                print(f"[enc] early stop @ {ep} (best val {best['val']:.2f})"); break
        if best["state"] is not None:
            net.load_state_dict(best["state"])
        net.eval()
        encW = {}; mods = list(net.enc.body); li = 0
        for i in range(0, len(mods), 3):
            conv = mods[i]; bn = mods[i + 1]
            Wc = conv.weight.detach().numpy().astype(np.float64)
            g = bn.weight.detach().numpy().astype(np.float64); be = bn.bias.detach().numpy().astype(np.float64)
            mu = bn.running_mean.detach().numpy().astype(np.float64); var = bn.running_var.detach().numpy().astype(np.float64)
            scale = g / np.sqrt(var + bn.eps)
            encW[f"c{li}_w"] = Wc * scale[:, None, None]; encW[f"c{li}_b"] = be - scale * mu; li += 1
        return encW

    def _build_fused(self, hand, trk, raw, rid, ons, encW):
        """Return (Xgbm (N,179), Xtcn (N,181), order_by_rec dict). Xtcn adds
        elapsed(2); both share hand+cross+emb+ema. EMA + elapsed computed in
        sorted-onset (=forward time) order per recording."""
        E = _np_embed(raw, encW)
        cross = crosschan(raw, self.sfreq)
        base = np.concatenate([hand, cross, E], axis=1)   # (N, 169)
        first = {}
        for i in range(len(rid)):
            k = (int(rid[i]), round(float(ons[i]), 3))
            if k not in first:
                first[k] = i
        # per (recording, onset): EMA state (from the first occurrence's tracked) + position
        smap = {}; order = {}
        for r in np.unique(rid):
            os_r = sorted({round(float(o), 3) for o in ons[rid == r]})
            ef = es = None; prev = None; idxs = []
            for pos, o in enumerate(os_r):
                i = first[(int(r), o)]; idxs.append(i); t = trk[i]
                if prev is None or abs(o - (prev + STEP)) > 1e-6:
                    ef = t.copy(); es = t.copy()
                else:
                    ef = A_FAST * t + (1 - A_FAST) * ef
                    es = A_SLOW * t + (1 - A_SLOW) * es
                smap[(int(r), o)] = (ef.copy(), es.copy(), pos); prev = o
            order[int(r)] = idxs
        Xg = np.zeros((len(rid), base.shape[1] + 10), dtype=np.float64)
        Xt = np.zeros((len(rid), base.shape[1] + 12), dtype=np.float64)
        for i in range(len(rid)):
            ef, es, pos = smap[(int(rid[i]), round(float(ons[i]), 3))]
            row = np.concatenate([base[i], ef, es])
            Xg[i] = row
            Xt[i] = np.concatenate([row, _elapsed_feats(pos)])
        return Xg, Xt, order

    def _train_gbm_heads(self, Xg, y, max_iter=60):
        sw = BIN_WEIGHTS[np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)]
        pipe = Pipeline([("s", StandardScaler()),
                         ("r", HistGradientBoostingRegressor(loss="absolute_error", max_iter=max_iter))])
        pipe.fit(Xg, y, r__sample_weight=sw)
        mnear = y < NEAR_FIT
        pipe_near = Pipeline([("s", StandardScaler()),
                              ("r", HistGradientBoostingRegressor(loss="absolute_error", max_iter=max_iter))])
        pipe_near.fit(Xg[mnear], y[mnear], r__sample_weight=sw[mnear])
        lab = (y < IMM_T).astype(int)
        npos = max(int(lab.sum()), 1); nneg = max(int((1 - lab).sum()), 1)
        cw = np.where(lab == 1, len(lab) / (2.0 * npos), len(lab) / (2.0 * nneg))
        clf = Pipeline([("s", StandardScaler()), ("c", HistGradientBoostingClassifier(max_iter=max_iter))])
        clf.fit(Xg, lab, c__sample_weight=cw)
        Greg, Gnear, Gclf = _export_gbm(pipe), _export_gbm(pipe_near), _export_gbm(clf)
        chk = Xg[:200]
        d_reg = np.abs(np.array([_gbm_raw(chk[i], Greg) for i in range(len(chk))]) - pipe.predict(chk)).max()
        d_clf = np.abs(1 / (1 + np.exp(-np.array([_gbm_raw(chk[i], Gclf) for i in range(len(chk))])))
                       - clf.predict_proba(chk)[:, 1]).max()
        print(f"[gbm] numpy-traversal vs sklearn  reg={d_reg:.2e}  clf={d_clf:.2e}  (want ~0)")
        return Greg, Gnear, Gclf

    def _gbm_blend(self, Xg, Greg, Gnear, Gclf):
        out = np.empty(len(Xg))
        for i in range(len(Xg)):
            p_reg = min(max(_gbm_raw(Xg[i], Greg), 0.0), CAP)
            p_near = min(max(_gbm_raw(Xg[i], Gnear), 0.0), CAP)
            p_imm = 1.0 / (1.0 + np.exp(-_gbm_raw(Xg[i], Gclf)))
            out[i] = p_imm * p_near + (1.0 - p_imm) * p_reg
        return np.clip(out, 0.0, CAP)

    def _train_tcn(self, Xt, y, order, rid, fmean, fstd, seed=0):
        import torch
        import torch.nn as nn
        torch.manual_seed(seed)
        Fdim = Xt.shape[1]

        class ChanLN(nn.Module):
            def __init__(self, C):
                super().__init__()
                self.g = nn.Parameter(torch.ones(C)); self.b = nn.Parameter(torch.zeros(C))

            def forward(self, h):  # (B,C,T)
                mu = h.mean(1, keepdim=True); var = h.var(1, unbiased=False, keepdim=True)
                return (h - mu) / torch.sqrt(var + LN_EPS) * self.g[None, :, None] + self.b[None, :, None]

        class TCN(nn.Module):
            def __init__(self, F):
                super().__init__()
                self.inp = nn.Conv1d(F, HID, 1)
                self.blocks = nn.ModuleList([nn.Conv1d(HID, HID, KERNEL, dilation=d) for d in DILATIONS])
                self.lns = nn.ModuleList([ChanLN(HID) for _ in DILATIONS])
                self.drop = nn.Dropout(TCN_DROP)
                self.out = nn.Conv1d(HID, 1, 1)

            def forward(self, x):   # (B,F,T)
                h = torch.relu(self.inp(x))
                for conv, ln, d in zip(self.blocks, self.lns, DILATIONS):
                    z = conv(torch.nn.functional.pad(h, ((KERNEL - 1) * d, 0)))
                    z = self.drop(torch.relu(ln(z)))
                    h = h + z
                return self.out(h)[:, 0, :]

        # build per-recording standardized sequences
        recs = list(order.keys())
        seqs = []
        for r in recs:
            idxs = order[r]
            F = ((Xt[idxs] - fmean) / fstd).T.astype(np.float32)   # (F,T)
            yv = y[idxs].astype(np.float32)
            sw = BIN_WEIGHTS[np.clip(np.digitize(yv, BIN_EDGES[1:-1]), 0, 3)].astype(np.float32)
            seqs.append((F, yv, sw))
        rng = np.random.default_rng(seed)
        ridx = np.arange(len(seqs)); rng.shuffle(ridx)
        nval = max(1, int(0.15 * len(ridx)))
        va = set(ridx[:nval].tolist()); tr = [i for i in range(len(seqs)) if i not in va]
        va = sorted(va)

        def batch_tensors(ids):
            Tmax = max(seqs[i][0].shape[1] for i in ids)
            B = len(ids); F = Fdim
            xb = np.zeros((B, F, Tmax), np.float32); yb = np.zeros((B, Tmax), np.float32)
            wb = np.zeros((B, Tmax), np.float32)
            for bi, i in enumerate(ids):
                Fseq, yv, sw = seqs[i]; L = Fseq.shape[1]
                xb[bi, :, :L] = Fseq; yb[bi, :L] = yv; wb[bi, :L] = sw
            return (torch.tensor(xb), torch.tensor(yb), torch.tensor(wb))

        net = TCN(Fdim)
        opt = torch.optim.Adam(net.parameters(), lr=TCN_LR, weight_decay=TCN_WD)
        vx, vy, vw = batch_tensors(va)
        best = {"val": np.inf, "state": None}; bad = 0
        for ep in range(TCN_EPOCHS):
            net.train(); perm = [tr[i] for i in rng.permutation(len(tr))]
            for s in range(0, len(perm), TCN_BATCH):
                ids = perm[s:s + TCN_BATCH]
                xb, yb, wb = batch_tensors(ids)
                opt.zero_grad()
                pred = net(xb).clamp(0, CAP)
                loss = (wb * (pred - yb).abs()).sum() / wb.sum().clamp_min(1.0)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
                opt.step()
            net.eval()
            with torch.no_grad():
                vp = net(vx).clamp(0, CAP)
                vloss = float((vw * (vp - vy).abs()).sum() / vw.sum().clamp_min(1.0))
            if vloss < best["val"] - 1e-3:
                best = {"val": vloss, "state": {k: v.clone() for k, v in net.state_dict().items()}}; bad = 0
            else:
                bad += 1
            if ep % 20 == 0 or ep == TCN_EPOCHS - 1:
                print(f"[tcn] epoch {ep:3d}  val-wL1 {vloss:.2f}")
            if bad >= TCN_PATIENCE:
                print(f"[tcn] early stop @ {ep} (best val {best['val']:.2f})"); break
        if best["state"] is not None:
            net.load_state_dict(best["state"])
        net.eval()
        sd = net.state_dict()
        W = {"in_w": sd["inp.weight"][:, :, 0].numpy().astype(np.float64),
             "in_b": sd["inp.bias"].numpy().astype(np.float64),
             "out_w": sd["out.weight"][:, :, 0].numpy().astype(np.float64),
             "out_b": sd["out.bias"].numpy().astype(np.float64)}
        for li in range(len(DILATIONS)):
            W[f"c{li}_w"] = sd[f"blocks.{li}.weight"].numpy().astype(np.float64)
            W[f"c{li}_b"] = sd[f"blocks.{li}.bias"].numpy().astype(np.float64)
            W[f"ln{li}_g"] = sd[f"lns.{li}.g"].numpy().astype(np.float64)
            W[f"ln{li}_b"] = sd[f"lns.{li}.b"].numpy().astype(np.float64)
        # equivalence check: torch full vs numpy full vs streaming (on a few seqs)
        d_full = d_stream = 0.0
        with torch.no_grad():
            for i in (tr[:3] + va[:2]):
                Fseq = (Xt[order[recs[i]]] - fmean) / fstd
                xb = torch.tensor(Fseq.T[None].astype(np.float32))
                tp = net(xb).clamp(0, CAP)[0].numpy()
                npf = _np_tcn_full(Fseq.T.astype(np.float64), W)
                d_full = max(d_full, float(np.abs(tp - npf).max()))
                st = _StreamTCN(W); sp = np.array([st.step(Fseq[k]) for k in range(len(Fseq))])
                d_stream = max(d_stream, float(np.abs(sp - npf).max()))
        print(f"[tcn] torch-vs-numpy full max|diff|={d_full:.3e}  stream-vs-full max|diff|={d_stream:.3e} (want <1e-3)")
        print(f"[tcn] Fdim={Fdim}  HID={HID}  RF={RF} windows (~{RF*STEP/60:.1f} min)")
        return W

    def _wbmae(self, y_true, y_pred, rid):
        from benchmark_utils.metrics import binned_mae, group_scores
        import functools
        f = functools.partial(binned_mae, bin_edges=tuple(BIN_EDGES.tolist()),
                              bin_weights=tuple(BIN_WEIGHTS.tolist()))
        return float(group_scores(f, y_true, y_pred, rid).mean())

    def _countdown(self, raw, order):
        """apply the countdown filter per recording (faithful to streaming)."""
        out = np.zeros_like(raw)
        for r, idxs in order.items():
            cd = None
            for i in idxs:
                est = raw[i] if cd is None else ALPHA * raw[i] + (1 - ALPHA) * max(cd - STEP, 0.0)
                est = min(max(est, 0.0), CAP); cd = est; out[i] = est
        return out

    def fit(self, loader):
        hand, trk, raw, rid, ons, y = self._gather(loader)
        # ---- diagnostic fold: train on tr recordings, tune blend on holdout ----
        rng = np.random.default_rng(33); urec = np.unique(rid); rng.shuffle(urec)
        ho_rec = set(urec[:max(1, int(0.2 * len(urec)))].tolist())
        trm = np.array([int(r) not in ho_rec for r in rid])
        tr_i = np.where(trm)[0]; ho_i = np.where(~trm)[0]
        print(f"[fold] {len(urec)} recordings -> train {len(urec)-len(ho_rec)} / holdout {len(ho_rec)}")
        encW_f = self._train_encoder(raw[tr_i], y[tr_i], rid[tr_i], seed=0)
        Xg, Xt, order = self._build_fused(hand, trk, raw, rid, ons, encW_f)
        Greg, Gnear, Gclf = self._train_gbm_heads(Xg[tr_i], y[tr_i])
        fmean = Xt[tr_i].mean(0); fstd = Xt[tr_i].std(0) + 1e-6
        order_tr = {r: [i for i in idxs if trm[i]] for r, idxs in order.items()}
        order_tr = {r: v for r, v in order_tr.items() if v}
        W_f = self._train_tcn(Xt, y, order_tr, rid, fmean, fstd, seed=0)
        # ---- holdout eval, built DIRECTLY from the holdout recordings (aligned
        #      flat arrays; no indexing by row-mask, no uninitialized buffers) ----
        order_ho = {r: [i for i in idxs if not trm[i]] for r, idxs in order.items()}
        order_ho = {r: v for r, v in order_ho.items() if v}
        flat = [i for idxs in order_ho.values() for i in idxs]     # eval order
        g_flat = self._gbm_blend(Xg[flat], Greg, Gnear, Gclf)       # aligned w/ flat
        g_lut = {i: float(g_flat[k]) for k, i in enumerate(flat)}
        t_lut = {}
        for r, idxs in order_ho.items():
            Fseq = (Xt[idxs] - fmean) / fstd
            tp = _np_tcn_full(Fseq.T.astype(np.float64), W_f)
            for k, i in enumerate(idxs):
                t_lut[i] = float(tp[k])
        y_flat = np.array([y[i] for i in flat], dtype=np.float64)
        rid_flat = np.array([rid[i] for i in flat])

        def _blend_cd(w):
            """clip(w*tcn+(1-w)*gbm) then per-recording countdown; returns flat preds."""
            preds = np.empty(len(flat)); p = 0
            for r, idxs in order_ho.items():
                cd = None
                for i in idxs:
                    raw = min(max(w * t_lut[i] + (1 - w) * g_lut[i], 0.0), CAP)
                    est = raw if cd is None else ALPHA * raw + (1 - ALPHA) * max(cd - STEP, 0.0)
                    est = min(max(est, 0.0), CAP); cd = est
                    preds[p] = est; p += 1
            return preds

        results = [(w, self._wbmae(y_flat, _blend_cd(w), rid_flat)) for w in W_GRID]
        best_w, best_s = min(results, key=lambda t: t[1])
        print("[blend] holdout W-bMAE by TCN weight (W_TCN=0.00 == pure Fast3NX GBM, "
              "fold baseline; lower=better):")
        for w, s in results:
            print(f"   W_TCN={w:.2f}   W-bMAE={s:7.3f}{'   <-- best' if w == best_w else ''}")
        # per-bin |err|: pure GBM (w=0) vs chosen blend
        pg = _blend_cd(0.0); pb = _blend_cd(best_w)
        bi = np.clip(np.digitize(y_flat, BIN_EDGES[1:-1]), 0, 3)
        print(f"[blend] chosen W_TCN={best_w:.2f}  (holdout {best_s:.3f});  per-bin |err| GBM vs blend:")
        for b, lab in enumerate(["[0,40)", "[40,90)", "[90,300)", "[300,600]"]):
            mk = bi == b
            if mk.any():
                print(f"   {lab:12s} GBM {np.abs(pg[mk]-y_flat[mk]).mean():6.1f}   "
                      f"blend {np.abs(pb[mk]-y_flat[mk]).mean():6.1f}  (n={int(mk.sum())})")
        self.w_tcn = best_w
        # ---- final fit on ALL data ----
        print("[final] retraining encoder + GBM + TCN on ALL recordings ...")
        self.encW = self._train_encoder(raw, y, rid, seed=0)
        Xg2, Xt2, order2 = self._build_fused(hand, trk, raw, rid, ons, self.encW)
        self.Greg, self.Gnear, self.Gclf = self._train_gbm_heads(Xg2, y)
        self.fmean = Xt2.mean(0); self.fstd = Xt2.std(0) + 1e-6
        self.W = self._train_tcn(Xt2, y, order2, rid, self.fmean, self.fstd, seed=0)
        print(f"[final] done.  w_tcn={self.w_tcn:.2f}  fused_gbm={Xg2.shape[1]}  tcn_in={Xt2.shape[1]}")
        return self

    def predict(self, X):
        o, trk, Xr = compute(X, self.sfreq)
        E = _np_embed(Xr, self.encW)
        xc = crosschan(Xr, self.sfreq)
        out = np.empty(len(o))
        for i in range(len(o)):
            t = trk[i]
            if self._ef is None:
                self._ef = t.copy(); self._es = t.copy()
            else:
                self._ef = A_FAST * t + (1 - A_FAST) * self._ef
                self._es = A_SLOW * t + (1 - A_SLOW) * self._es
            base = np.concatenate([o[i], xc[i], E[i], self._ef, self._es])
            # GBM 3-head blend
            p_reg = min(max(_gbm_raw(base, self.Greg), 0.0), CAP)
            p_near = min(max(_gbm_raw(base, self.Gnear), 0.0), CAP)
            p_imm = 1.0 / (1.0 + np.exp(-_gbm_raw(base, self.Gclf)))
            gbm = p_imm * p_near + (1.0 - p_imm) * p_reg
            # TCN (streaming, O(1)) on the standardized [base + elapsed]
            if self.w_tcn > 0.0 and self._stream is not None:
                xt = (np.concatenate([base, _elapsed_feats(self._i)]) - self.fmean) / self.fstd
                tcn = self._stream.step(xt)
                raw = self.w_tcn * tcn + (1.0 - self.w_tcn) * gbm
            else:
                raw = gbm
                if self._stream is not None:
                    xt = (np.concatenate([base, _elapsed_feats(self._i)]) - self.fmean) / self.fstd
                    self._stream.step(xt)   # keep buffers warm even at w=0 (harmless)
            raw = min(max(raw, 0.0), CAP)
            est = raw if self._cd is None else ALPHA * raw + (1 - ALPHA) * max(self._cd - STEP, 0.0)
            est = min(max(est, 0.0), CAP)
            self._cd = est; self._i += 1; out[i] = est
        return out


class Solver(CompetSolver):
    name = "Smooth-Causal-TCN"
    requirements = []

    def load_model(self, meta):
        mdl = CausalTCN(meta)
        w = meta["submission_dir"] / "weights.joblib"
        if w.exists():
            ck = joblib.load(w)
            mdl.encW = ck["encW"]; mdl.Greg = ck["Greg"]; mdl.Gnear = ck["Gnear"]; mdl.Gclf = ck["Gclf"]
            mdl.W = ck["W"]; mdl.fmean = ck["fmean"]; mdl.fstd = ck["fstd"]; mdl.w_tcn = ck["w_tcn"]
        elif self.train_loader is None:
            raise FileNotFoundError("Smooth-Causal-TCN needs weights.joblib; train with training=True.")
        return mdl

    def fit(self, model, loader):
        model.fit(loader)

    def save_model(self, model, path):
        joblib.dump({"encW": model.encW, "Greg": model.Greg, "Gnear": model.Gnear,
                     "Gclf": model.Gclf, "W": model.W, "fmean": model.fmean,
                     "fstd": model.fstd, "w_tcn": model.w_tcn}, path / "weights.joblib")
