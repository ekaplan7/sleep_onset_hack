"""Smooth-Imminence (numpy): near-onset specialist, numpy-fast + channel-robust.

Faithful numpy port of the torch smooth_imminence (local 47.08). Three heads on
the lean feature set: (1) main bin-weighted regressor, (2) a near-specialist
regressor trained ONLY on windows < NEAR_FIT s to N2, (3) an imminence
CLASSIFIER P(N2 within IMM_T s). Blend = p_imm*near + (1-p_imm)*main, then the
countdown filter. The classifier gates the precise near estimate into exactly
the 10x/5x-weighted bins.

Features (lean, no FOOOF bloat, no python-loop complexity): per-channel bands,
1-range aperiodic exponent/offset, spectral entropy + edge, sigma-spindle
envelope, sigma oscillatory power above 1/f, K-complex peak-to-peak, Hjorth
mobility/complexity, 4-band waveform shape; plus cross-channel correlation /
asymmetry; plus causal fast/slow EMA of the key discriminators.

numpy + sklearn + joblib + benchmark_utils only. No torch. Channel-count robust.
"""

import joblib
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

from sklearn.ensemble import (HistGradientBoostingRegressor,
                              HistGradientBoostingClassifier)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from benchmark_utils.base_solver import CompetSolver
from benchmark_utils.data import to_numpy

BANDS = {"delta": (0.5, 4.0), "theta": (4.0, 8.0), "alpha": (8.0, 12.0),
         "sigma": (12.0, 16.0), "beta": (16.0, 30.0)}
SHAPE_BANDS = [(1.0, 8.0), (12.0, 16.0), (16.0, 30.0), (1.0, 40.0)]
FIT_LO, FIT_HI = 2.0, 40.0
EPS = 1e-8
CAP = 600.0
BIN_EDGES = np.array([0.0, 40.0, 90.0, 300.0, 600.0])
BIN_WEIGHTS = np.array([10.0, 5.0, 3.0, 1.0])
STEP = 5.0
A_FAST = 1.0 - 0.5 ** (1.0 / 6.0)
A_SLOW = 1.0 - 0.5 ** (1.0 / 24.0)
ALPHA = 0.4
NEAR_FIT = 90.0
IMM_T = 40.0
NCHAN = 4

_CACHE = {}


def _const(T, sf):
    key = (int(T), float(sf))
    c = _CACHE.get(key)
    if c is not None:
        return c
    T = int(T); sf = float(sf)
    n = np.arange(T)
    hann = (0.5 - 0.5 * np.cos(2.0 * np.pi * n / T)).astype(np.float32)
    freqs = np.fft.rfftfreq(T, d=1.0 / sf)
    logf = np.log10(np.clip(freqs, EPS, None))
    tmask = (freqs >= 1.0) & (freqs <= 40.0)
    bm = {k: ((freqs >= lo) & (freqs < hi)) for k, (lo, hi) in BANDS.items()}
    fm = (freqs >= FIT_LO) & (freqs <= FIT_HI)
    lf = np.log10(np.clip(freqs[fm], EPS, None)); lfc = lf - lf.mean()
    shape_m = [((freqs >= lo) & (freqs <= hi)) for lo, hi in SHAPE_BANDS]
    sp_m = (freqs >= 11.0) & (freqs <= 16.0)     # sigma spindle band (envelope)
    osc_m = (freqs >= 12.0) & (freqs < 16.0)     # sigma oscillatory (above 1/f)
    kc_m = (freqs >= 0.5) & (freqs <= 4.0)       # delta/KC band
    c = dict(hann=hann, freqs=freqs, logf=logf, tmask=tmask, bm=bm, fm=fm,
             lfc=lfc, lfcss=max(float((lfc ** 2).sum()), EPS), lfmean=float(lf.mean()),
             fb=freqs[tmask], shape_m=shape_m, sp_m=sp_m, osc_m=osc_m, kc_m=kc_m)
    _CACHE[key] = c
    return c


def _fix_channels(X, n=NCHAN):
    C = X.shape[1]
    if C == n:
        return X
    if C > n:
        return X[:, :n]
    reps = int(np.ceil(n / C))
    return np.tile(X, (1, reps, 1))[:, :n]


def _rollmaxp2p(kc, L):
    B, C, T = kc.shape
    if L >= T:
        pk = kc.max(-1) - kc.min(-1)
        return pk, pk
    sw = sliding_window_view(kc, L, axis=-1)
    p2p = sw.max(-1) - sw.min(-1)
    return p2p.max(-1), p2p.mean(-1)


def compute(X, sfreq):
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    c = _const(T, sfreq)
    freqs = c["freqs"]; logf = c["logf"]
    xw = (X - X.mean(-1, keepdims=True)) * c["hann"]
    spec = np.fft.rfft(xw, axis=-1)
    psd = spec.real ** 2 + spec.imag ** 2

    feats = []
    tmask = c["tmask"]
    total = np.clip(psd[..., tmask].sum(-1), EPS, None)
    bp = {}
    for name in BANDS:
        p = np.clip(psd[..., c["bm"][name]].sum(-1), EPS, None)
        bp[name] = p
        feats.append(np.log(p))
    for name in BANDS:
        feats.append(bp[name] / total)
    feats.append(bp["delta"] / bp["beta"])
    feats.append((bp["delta"] + bp["theta"]) / (bp["alpha"] + bp["beta"]))
    ly = np.log10(np.clip(psd[..., c["fm"]], EPS, None))
    ly_c = ly - ly.mean(-1, keepdims=True)
    slope = (ly_c * c["lfc"]).sum(-1) / c["lfcss"]
    exponent = -slope
    offset = ly.mean(-1) - slope * c["lfmean"]
    feats.append(exponent); feats.append(offset)
    p_b = psd[..., tmask]; f_b = c["fb"]
    tot = np.clip(p_b.sum(-1, keepdims=True), EPS, None); pn = p_b / tot
    feats.append(-(pn * np.log(pn + EPS)).sum(-1))
    cum = np.cumsum(p_b, -1) / tot
    feats.append(f_b[np.clip((cum < 0.95).sum(-1), 0, f_b.size - 1)])
    base = np.stack(feats, -1)

    Xd = X - X.mean(-1, keepdims=True)
    Sp = np.fft.rfft(Xd, axis=-1)

    def band_sig(mask):
        return np.fft.irfft(Sp * mask, n=T, axis=-1)

    # sigma spindle envelope peak
    sig = band_sig(c["sp_m"])
    w = max(int(0.25 * sfreq), 1); ker = np.ones(w, dtype=np.float32) / w
    env2 = np.apply_along_axis(lambda v: np.convolve(v, ker, mode="same"), -1, sig ** 2)
    sp_peak = np.sqrt(np.clip(env2, 0, None) + EPS).max(-1)
    # sigma oscillatory power above aperiodic
    ap = 10.0 ** (offset[..., None] - exponent[..., None] * logf[None, None, :])
    flat = np.clip(psd - ap, 0.0, None)
    osc = np.log(flat[..., c["osc_m"]].sum(-1) + EPS)
    # K-complex peak-to-peak
    kc = band_sig(c["kc_m"])
    kc = (kc - kc.mean(-1, keepdims=True)) / np.clip(kc.std(-1, keepdims=True), EPS, None)
    L = max(int(1.2 * sfreq), 1)
    kc_max, kc_mean = _rollmaxp2p(kc, L)
    # Hjorth
    d1 = np.diff(X, axis=-1); d2 = np.diff(d1, axis=-1)
    v0 = np.clip(X.var(-1), EPS, None); v1 = np.clip(d1.var(-1), EPS, None); v2 = np.clip(d2.var(-1), EPS, None)
    mob = np.sqrt(v1 / v0); cplx = np.sqrt(v2 / v1) / np.clip(mob, EPS, None)
    kept = np.stack([sp_peak, osc, kc_max, kc_mean, mob, cplx], -1)

    shape_cols = []
    for m in c["shape_m"]:
        s = np.fft.irfft(Sp * m, n=T, axis=-1)
        mu = s.mean(-1, keepdims=True); dd0 = s - mu
        sk = (dd0 ** 3).mean(-1) / ((dd0 ** 2).mean(-1) ** 1.5 + EPS)
        ll = np.abs(np.diff(s, axis=-1)).sum(-1) / (np.clip(s.std(-1), EPS, None) * T)
        shape_cols.append(sk); shape_cols.append(ll)
    shape = np.stack(shape_cols, -1)

    out = np.concatenate([base, kept, shape], -1)
    out = np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0).reshape(B, -1)

    tracked = np.stack([exponent.mean(1), (bp["sigma"] / total).mean(1),
                        np.log(bp["delta"] / bp["beta"]).mean(1),
                        (bp["alpha"] / total).mean(1), np.log(total).mean(1)], axis=1)
    tracked = np.nan_to_num(tracked, nan=0.0, posinf=0.0, neginf=0.0)
    return out, tracked


CROSS_BANDS = [(0.5, 4.0), (4.0, 8.0), (8.0, 12.0), (12.0, 16.0), (1.0, 40.0)]
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


def crosschan(X, sfreq):
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    freqs = np.fft.rfftfreq(T, d=1.0 / float(sfreq))
    Xd = X - X.mean(-1, keepdims=True)
    Sp = np.fft.rfft(Xd, axis=-1); psd = Sp.real ** 2 + Sp.imag ** 2
    feats = []
    for lo, hi in CROSS_BANDS:
        m = (freqs >= lo) & (freqs < hi)
        xb = np.fft.irfft(Sp * m, n=T, axis=-1)
        xc = xb - xb.mean(-1, keepdims=True)
        xn = xc / np.clip(xc.std(-1, keepdims=True), EPS, None)
        Cmat = np.matmul(xn, xn.transpose(0, 2, 1)) / T
        cp = np.stack([Cmat[:, i, j] for i, j in PAIRS], -1)
        p = np.clip(psd[..., m].sum(-1), EPS, None)
        feats.append(cp.mean(-1, keepdims=True))
        feats.append(Cmat[:, 1, 2:3]); feats.append(Cmat[:, 0, 3:4])
        feats.append(np.log(p[:, 1:2] / p[:, 2:3])); feats.append(np.log(p[:, 0:1] / p[:, 3:4]))
    out = np.concatenate(feats, -1)
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)


def _best_const(y):
    gr = np.arange(0.0, 600.01, 2.0)
    idx = np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)
    ne = [b for b in range(4) if np.any(idx == b)]
    s = [(BIN_WEIGHTS[ne] * np.array([np.abs(c - y)[idx == b].mean() for b in ne])).sum()
         / BIN_WEIGHTS[ne].sum() for c in gr]
    return float(gr[int(np.argmin(s))])


class CxSmoothImm:
    def __init__(self, meta):
        self.sfreq = float(meta["sfreq"]); self.device = meta.get("device", "cpu")
        self.pipe = None; self.pipe_near = None; self.clf = None
        self._ef = None; self._es = None; self._cd = None

    def reset_state(self):
        self._ef = None; self._es = None; self._cd = None

    def _assemble(self, loader):
        f, trk, rid, ons, Y = [], [], [], [], []
        for X, y, info in loader:
            o, t = compute(X, self.sfreq); xc = crosschan(X, self.sfreq)
            f.append(np.concatenate([o, xc], axis=1)); trk.append(t)
            rid.append(to_numpy(info["record_id"]).reshape(-1))
            ons.append(to_numpy(info["onset"]).reshape(-1)); Y.append(to_numpy(y).ravel())
        f = np.concatenate(f); trk = np.concatenate(trk)
        rid = np.concatenate(rid).astype(np.int64); ons = np.concatenate(ons).astype(np.float64)
        y = np.concatenate(Y)
        first = {}
        for i in range(len(y)):
            k = (int(rid[i]), round(float(ons[i]), 3))
            if k not in first:
                first[k] = i
        smap = {}
        for r in np.unique(rid):
            os_r = sorted({round(float(o), 3) for o in ons[rid == r]})   # ascending = forward time
            ef = es = None; prev = None
            for o in os_r:
                t = trk[first[(int(r), o)]]
                if prev is None or abs(o - (prev + STEP)) > 1e-6:
                    ef = t.copy(); es = t.copy()
                else:
                    ef = A_FAST * t + (1 - A_FAST) * ef
                    es = A_SLOW * t + (1 - A_SLOW) * es
                smap[(int(r), o)] = np.concatenate([ef, es]); prev = o
        S = np.stack([smap[(int(rid[i]), round(float(ons[i]), 3))] for i in range(len(y))])
        return np.concatenate([f, S], axis=1), y

    def fit(self, loader):
        Xf, y = self._assemble(loader)
        sw = BIN_WEIGHTS[np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)]
        rng = np.random.default_rng(33); idx = rng.permutation(len(y))
        cut = int(0.8 * len(y)); tr, ho = idx[:cut], idx[cut:]
        dg = Pipeline([("s", StandardScaler()), ("r", HistGradientBoostingRegressor(loss="absolute_error"))])
        dg.fit(Xf[tr], y[tr], r__sample_weight=sw[tr])
        c = _best_const(y[tr]); yh = y[ho]
        pg = np.clip(dg.predict(Xf[ho]), 0, 600); bi = np.clip(np.digitize(yh, BIN_EDGES[1:-1]), 0, 3)
        print(f"[imminence-np per-bin] c={c:.1f}  n_features={Xf.shape[1]}")
        print(f"{'bin':12s}{'GBM_MAE':>10s}{'const_MAE':>11s}{'gain':>8s}")
        for b, lab in enumerate(["[0,40)", "[40,90)", "[90,300)", "[300,600]"]):
            mk = bi == b
            if not mk.any():
                continue
            g = np.abs(pg[mk] - yh[mk]).mean(); cc = np.abs(c - yh[mk]).mean()
            print(f"{lab:12s}{g:>10.1f}{cc:>11.1f}{cc - g:>8.1f}")
        self.pipe = Pipeline([("scaler", StandardScaler()),
                              ("reg", HistGradientBoostingRegressor(loss="absolute_error"))])
        self.pipe.fit(Xf, y, reg__sample_weight=sw)
        m = y < NEAR_FIT
        self.pipe_near = Pipeline([("scaler", StandardScaler()),
                                   ("reg", HistGradientBoostingRegressor(loss="absolute_error"))])
        self.pipe_near.fit(Xf[m], y[m], reg__sample_weight=sw[m])
        lab = (y < IMM_T).astype(int)
        npos = max(int(lab.sum()), 1); nneg = max(int((1 - lab).sum()), 1)
        cw = np.where(lab == 1, len(lab) / (2.0 * npos), len(lab) / (2.0 * nneg))
        self.clf = Pipeline([("scaler", StandardScaler()), ("clf", HistGradientBoostingClassifier())])
        self.clf.fit(Xf, lab, clf__sample_weight=cw)
        return self

    def predict(self, X):
        o, trk = compute(X, self.sfreq); xc = crosschan(X, self.sfreq)
        rows = []
        for i in range(len(o)):
            t = trk[i]
            if self._ef is None:
                self._ef = t.copy(); self._es = t.copy()
            else:
                self._ef = A_FAST * t + (1 - A_FAST) * self._ef
                self._es = A_SLOW * t + (1 - A_SLOW) * self._es
            rows.append(np.concatenate([o[i], xc[i], self._ef, self._es]))
        R = np.array(rows)
        p_reg = np.clip(self.pipe.predict(R), 0.0, CAP)
        p_near = np.clip(self.pipe_near.predict(R), 0.0, CAP)
        p_imm = self.clf.predict_proba(R)[:, 1]
        raw = np.clip(p_imm * p_near + (1.0 - p_imm) * p_reg, 0.0, CAP)
        out = np.empty_like(raw)
        for i in range(len(raw)):
            est = raw[i] if self._cd is None else ALPHA * raw[i] + (1 - ALPHA) * max(self._cd - STEP, 0.0)
            est = min(max(est, 0.0), CAP); self._cd = est; out[i] = est
        return out


class Solver(CompetSolver):
    name = "Smooth-Imminence-NP"
    requirements = []

    def load_model(self, meta):
        mdl = CxSmoothImm(meta)
        w = meta["submission_dir"] / "weights.joblib"
        if w.exists():
            ck = joblib.load(w)
            mdl.pipe = ck["pipe"]; mdl.pipe_near = ck["pipe_near"]; mdl.clf = ck["clf"]
        elif self.train_loader is None:
            raise FileNotFoundError("Smooth-Imminence-NP needs weights.joblib; train with training=True.")
        return mdl

    def fit(self, model, loader):
        model.fit(loader)

    def save_model(self, model, path):
        joblib.dump({"pipe": model.pipe, "pipe_near": model.pipe_near, "clf": model.clf},
                    path / "weights.joblib")
