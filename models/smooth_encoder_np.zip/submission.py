"""Smooth-Encoder-NP: learned raw-signal encoder fused with the GBM stack.

The one lever left against the ~47 ceiling: hand features cap near-onset signal,
so LEARN features from the raw window. A small per-channel shared 1D-CNN is
trained END-TO-END on raw z-scored windows with the bin-weighted objective (so
it learns onset-relevant structure, not generic staging). Its embedding is
fused with the imminence hand features and fed to the 3-head GBM (main +
near-specialist + P(N2<40s)), then blended p_imm and countdown-filtered.

TRAINING (fit) uses torch -- offline on the user's machine. BatchNorm is folded
into the convs at export, so INFERENCE is a pure-numpy conv+ReLU+avgpool forward
over the current window (O(1) per window, no torch). The GBM is trained on the
*numpy* embeddings, so there is zero torch-vs-numpy drift; fit also prints an
equivalence check. numpy + sklearn + joblib (+ torch only inside fit).
Channel-count robust.
"""

import joblib
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

from sklearn.ensemble import (HistGradientBoostingRegressor,
                              HistGradientBoostingClassifier)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from benchmark_utils.base_solver import CompetSolver
from benchmark_utils.data import to_numpy

BANDS = {"delta": (0.5, 4.0), "theta": (4.0, 8.0), "alpha": (8.0, 12.0),
         "sigma": (12.0, 16.0), "beta": (16.0, 30.0)}
SHAPE_BANDS = [(1.0, 8.0), (12.0, 16.0), (16.0, 30.0), (1.0, 40.0)]
FIT_LO, FIT_HI = 2.0, 40.0
EPS = 1e-8
CAP = 600.0
BIN_EDGES = np.array([0.0, 40.0, 90.0, 300.0, 600.0])
BIN_WEIGHTS = np.array([10.0, 5.0, 3.0, 1.0])
STEP = 5.0
A_FAST = 1.0 - 0.5 ** (1.0 / 6.0)
A_SLOW = 1.0 - 0.5 ** (1.0 / 24.0)
ALPHA = 0.4
NEAR_FIT = 90.0
IMM_T = 40.0
NCHAN = 4
# encoder architecture (per channel, shared weights)
ENC_CH = [16, 24, 32, 16]
ENC_K = [7, 5, 5, 5]
ENC_S = [2, 2, 2, 2]
ENC_P = [3, 2, 2, 2]
EMB = ENC_CH[-1]              # per-channel embedding dim -> 4*EMB total
EPOCHS = 60
LR = 2e-3
BATCH = 256

_CACHE = {}


def _const(T, sf):
    key = (int(T), float(sf))
    c = _CACHE.get(key)
    if c is not None:
        return c
    T = int(T); sf = float(sf)
    n = np.arange(T)
    hann = (0.5 - 0.5 * np.cos(2.0 * np.pi * n / T)).astype(np.float32)
    freqs = np.fft.rfftfreq(T, d=1.0 / sf)
    logf = np.log10(np.clip(freqs, EPS, None))
    tmask = (freqs >= 1.0) & (freqs <= 40.0)
    bm = {k: ((freqs >= lo) & (freqs < hi)) for k, (lo, hi) in BANDS.items()}
    fm = (freqs >= FIT_LO) & (freqs <= FIT_HI)
    lf = np.log10(np.clip(freqs[fm], EPS, None)); lfc = lf - lf.mean()
    shape_m = [((freqs >= lo) & (freqs <= hi)) for lo, hi in SHAPE_BANDS]
    c = dict(hann=hann, freqs=freqs, logf=logf, tmask=tmask, bm=bm, fm=fm,
             lfc=lfc, lfcss=max(float((lfc ** 2).sum()), EPS), lfmean=float(lf.mean()),
             fb=freqs[tmask], shape_m=shape_m,
             sp_m=(freqs >= 11.0) & (freqs <= 16.0),
             osc_m=(freqs >= 12.0) & (freqs < 16.0),
             kc_m=(freqs >= 0.5) & (freqs <= 4.0))
    _CACHE[key] = c
    return c


def _fix_channels(X, n=NCHAN):
    C = X.shape[1]
    if C == n:
        return X
    if C > n:
        return X[:, :n]
    reps = int(np.ceil(n / C))
    return np.tile(X, (1, reps, 1))[:, :n]


def _rollmaxp2p(kc, L):
    B, C, T = kc.shape
    if L >= T:
        pk = kc.max(-1) - kc.min(-1)
        return pk, pk
    sw = sliding_window_view(kc, L, axis=-1)
    p2p = sw.max(-1) - sw.min(-1)
    return p2p.max(-1), p2p.mean(-1)


def compute(X, sfreq):
    """imminence hand features (B,C*30) + tracked (B,5). Also returns raw X."""
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    c = _const(T, sfreq)
    freqs = c["freqs"]; logf = c["logf"]
    xw = (X - X.mean(-1, keepdims=True)) * c["hann"]
    spec = np.fft.rfft(xw, axis=-1)
    psd = spec.real ** 2 + spec.imag ** 2
    tmask = c["tmask"]
    total = np.clip(psd[..., tmask].sum(-1), EPS, None)
    bp = {k: np.clip(psd[..., c["bm"][k]].sum(-1), EPS, None) for k in BANDS}
    feats = []
    for k in BANDS:
        feats.append(np.log(bp[k]))
    for k in BANDS:
        feats.append(bp[k] / total)
    feats.append(bp["delta"] / bp["beta"])
    feats.append((bp["delta"] + bp["theta"]) / (bp["alpha"] + bp["beta"]))
    ly = np.log10(np.clip(psd[..., c["fm"]], EPS, None))
    ly_c = ly - ly.mean(-1, keepdims=True)
    slope = (ly_c * c["lfc"]).sum(-1) / c["lfcss"]
    exponent = -slope; offset = ly.mean(-1) - slope * c["lfmean"]
    feats.append(exponent); feats.append(offset)
    p_b = psd[..., tmask]; f_b = c["fb"]
    tot = np.clip(p_b.sum(-1, keepdims=True), EPS, None); pn = p_b / tot
    feats.append(-(pn * np.log(pn + EPS)).sum(-1))
    cum = np.cumsum(p_b, -1) / tot
    feats.append(f_b[np.clip((cum < 0.95).sum(-1), 0, f_b.size - 1)])
    base = np.stack(feats, -1)
    Xd = X - X.mean(-1, keepdims=True); Sp = np.fft.rfft(Xd, axis=-1)
    sig = np.fft.irfft(Sp * c["sp_m"], n=T, axis=-1)
    w = max(int(0.25 * sfreq), 1); ker = np.ones(w, dtype=np.float32) / w
    env2 = np.apply_along_axis(lambda v: np.convolve(v, ker, mode="same"), -1, sig ** 2)
    sp_peak = np.sqrt(np.clip(env2, 0, None) + EPS).max(-1)
    ap = 10.0 ** (offset[..., None] - exponent[..., None] * logf[None, None, :])
    flat = np.clip(psd - ap, 0.0, None)
    osc = np.log(flat[..., c["osc_m"]].sum(-1) + EPS)
    kc = np.fft.irfft(Sp * c["kc_m"], n=T, axis=-1)
    kc = (kc - kc.mean(-1, keepdims=True)) / np.clip(kc.std(-1, keepdims=True), EPS, None)
    L = max(int(1.2 * sfreq), 1)
    kc_max, kc_mean = _rollmaxp2p(kc, L)
    d1 = np.diff(X, axis=-1); d2 = np.diff(d1, axis=-1)
    v0 = np.clip(X.var(-1), EPS, None); v1 = np.clip(d1.var(-1), EPS, None); v2 = np.clip(d2.var(-1), EPS, None)
    mob = np.sqrt(v1 / v0); cplx = np.sqrt(v2 / v1) / np.clip(mob, EPS, None)
    kept = np.stack([sp_peak, osc, kc_max, kc_mean, mob, cplx], -1)
    shape_cols = []
    for m in c["shape_m"]:
        s = np.fft.irfft(Sp * m, n=T, axis=-1)
        mu = s.mean(-1, keepdims=True); dd0 = s - mu
        sk = (dd0 ** 3).mean(-1) / ((dd0 ** 2).mean(-1) ** 1.5 + EPS)
        ll = np.abs(np.diff(s, axis=-1)).sum(-1) / (np.clip(s.std(-1), EPS, None) * T)
        shape_cols.append(sk); shape_cols.append(ll)
    shape = np.stack(shape_cols, -1)
    out = np.concatenate([base, kept, shape], -1)
    out = np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0).reshape(B, -1)
    tracked = np.stack([exponent.mean(1), (bp["sigma"] / total).mean(1),
                        np.log(bp["delta"] / bp["beta"]).mean(1),
                        (bp["alpha"] / total).mean(1), np.log(total).mean(1)], axis=1)
    tracked = np.nan_to_num(tracked, nan=0.0, posinf=0.0, neginf=0.0)
    return out, tracked, X        # X = channel-fixed raw windows (B,4,T)


CROSS_BANDS = [(0.5, 4.0), (4.0, 8.0), (8.0, 12.0), (12.0, 16.0), (1.0, 40.0)]
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


def crosschan(X, sfreq):
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    freqs = np.fft.rfftfreq(T, d=1.0 / float(sfreq))
    Xd = X - X.mean(-1, keepdims=True)
    Sp = np.fft.rfft(Xd, axis=-1); psd = Sp.real ** 2 + Sp.imag ** 2
    feats = []
    for lo, hi in CROSS_BANDS:
        m = (freqs >= lo) & (freqs < hi)
        xb = np.fft.irfft(Sp * m, n=T, axis=-1)
        xc = xb - xb.mean(-1, keepdims=True)
        xn = xc / np.clip(xc.std(-1, keepdims=True), EPS, None)
        Cmat = np.matmul(xn, xn.transpose(0, 2, 1)) / T
        cp = np.stack([Cmat[:, i, j] for i, j in PAIRS], -1)
        p = np.clip(psd[..., m].sum(-1), EPS, None)
        feats.append(cp.mean(-1, keepdims=True))
        feats.append(Cmat[:, 1, 2:3]); feats.append(Cmat[:, 0, 3:4])
        feats.append(np.log(p[:, 1:2] / p[:, 2:3])); feats.append(np.log(p[:, 0:1] / p[:, 3:4]))
    out = np.concatenate(feats, -1)
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)


def _best_const(y):
    gr = np.arange(0.0, 600.01, 2.0)
    idx = np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)
    ne = [b for b in range(4) if np.any(idx == b)]
    s = [(BIN_WEIGHTS[ne] * np.array([np.abs(cc - y)[idx == b].mean() for b in ne])).sum()
         / BIN_WEIGHTS[ne].sum() for cc in gr]
    return float(gr[int(np.argmin(s))])


# ---------------------- numpy encoder (BN folded into convs) ----------------------
def _np_conv1d(x, W, b, stride, pad):
    Cout, Cin, k = W.shape
    xp = np.pad(x, ((0, 0), (pad, pad)))
    Tout = (xp.shape[1] - k) // stride + 1
    out = np.zeros((Cout, Tout), dtype=np.float64)
    for j in range(k):
        out += W[:, :, j] @ xp[:, j: j + stride * Tout: stride]
    return out + b[:, None]


def _np_embed(Xb, encW):
    """Xb:(B,4,T) raw -> (B, 4*EMB) numpy embedding (z-score per channel-window)."""
    B = Xb.shape[0]
    out = np.empty((B, NCHAN * EMB), dtype=np.float64)
    for bi in range(B):
        parts = []
        for ch in range(NCHAN):
            x = Xb[bi, ch:ch + 1].astype(np.float64)
            x = (x - x.mean()) / (x.std() + 1e-6)
            for li in range(len(ENC_CH)):
                x = _np_conv1d(x, encW[f"c{li}_w"], encW[f"c{li}_b"], ENC_S[li], ENC_P[li])
                x = np.maximum(x, 0.0)
            parts.append(x.mean(-1))
        out[bi] = np.concatenate(parts)
    return out


class SmoothEncoder:
    def __init__(self, meta):
        self.sfreq = float(meta["sfreq"]); self.device = meta.get("device", "cpu")
        self.encW = None
        self.pipe = None; self.pipe_near = None; self.clf = None
        self._ef = None; self._es = None; self._cd = None

    def reset_state(self):
        self._ef = None; self._es = None; self._cd = None

    def _gather(self, loader):
        hand, trk, raw, rid, ons, Y = [], [], [], [], [], []
        for X, y, info in loader:
            o, t, Xr = compute(X, self.sfreq); xc = crosschan(X, self.sfreq)
            hand.append(np.concatenate([o, xc], axis=1)); trk.append(t); raw.append(Xr)
            rid.append(to_numpy(info["record_id"]).reshape(-1))
            ons.append(to_numpy(info["onset"]).reshape(-1)); Y.append(to_numpy(y).ravel())
        return (np.concatenate(hand), np.concatenate(trk), np.concatenate(raw),
                np.concatenate(rid).astype(np.int64), np.concatenate(ons).astype(np.float64),
                np.concatenate(Y))

    def _ema_assemble(self, fused, trk, rid, ons, y):
        first = {}
        for i in range(len(y)):
            k = (int(rid[i]), round(float(ons[i]), 3))
            if k not in first:
                first[k] = i
        smap = {}
        for r in np.unique(rid):
            os_r = sorted({round(float(o), 3) for o in ons[rid == r]})
            ef = es = None; prev = None
            for o in os_r:
                t = trk[first[(int(r), o)]]
                if prev is None or abs(o - (prev + STEP)) > 1e-6:
                    ef = t.copy(); es = t.copy()
                else:
                    ef = A_FAST * t + (1 - A_FAST) * ef
                    es = A_SLOW * t + (1 - A_SLOW) * es
                smap[(int(r), o)] = np.concatenate([ef, es]); prev = o
        S = np.stack([smap[(int(rid[i]), round(float(ons[i]), 3))] for i in range(len(y))])
        return np.concatenate([fused, S], axis=1)

    def _train_encoder(self, raw, y, rid):
        import torch
        import torch.nn as nn

        class Enc(nn.Module):
            def __init__(self):
                super().__init__()
                layers = []; cin = 1
                for co, k, s, p in zip(ENC_CH, ENC_K, ENC_S, ENC_P):
                    layers += [nn.Conv1d(cin, co, k, stride=s, padding=p, bias=False), nn.BatchNorm1d(co), nn.ReLU()]
                    cin = co
                self.body = nn.Sequential(*layers)
            def forward(self, x):      # x:(N,1,T)
                return self.body(x).mean(-1)    # (N, EMB)

        class Net(nn.Module):
            def __init__(self):
                super().__init__()
                self.enc = Enc()
                self.drop = nn.Dropout(0.4)
                self.head = nn.Sequential(nn.Linear(NCHAN * EMB, 64), nn.ReLU(), nn.Dropout(0.4), nn.Linear(64, 1))
            def forward(self, x4):     # x4:(N,4,T)
                N = x4.shape[0]
                z = x4.reshape(N * NCHAN, 1, x4.shape[-1])
                m = z.mean(-1, keepdim=True); sd = z.std(-1, keepdim=True).clamp_min(1e-6)
                z = (z - m) / sd
                e = self.drop(self.enc(z).reshape(N, NCHAN * EMB))
                return self.head(e)[:, 0]

        net = Net()
        opt = torch.optim.Adam(net.parameters(), lr=LR, weight_decay=1e-4)
        Xt = torch.tensor(raw.astype(np.float32))
        yt = torch.tensor(y.astype(np.float32))
        sw = torch.tensor(BIN_WEIGHTS[np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)].astype(np.float32))
        # recording-level split: early-stop on UNSEEN recordings (true generalization)
        rng = np.random.default_rng(0)
        urec = np.unique(rid); rng.shuffle(urec)
        nval = max(1, int(0.15 * len(urec))); valrec = set(urec[:nval].tolist())
        vmask = np.array([r in valrec for r in rid])
        tr_idx = np.where(~vmask)[0]; va_idx = np.where(vmask)[0]
        best = {"val": np.inf, "state": None, "ep": 0}; patience = 8; bad = 0
        for ep in range(EPOCHS):
            net.train()
            perm = rng.permutation(tr_idx); tot = 0.0; nb = 0
            for s in range(0, len(perm), BATCH):
                idx = perm[s:s + BATCH]
                opt.zero_grad()
                pred = net(Xt[idx]).clamp(0, CAP)
                loss = (sw[idx] * (pred - yt[idx]).abs()).mean()
                loss.backward(); opt.step(); tot += float(loss); nb += 1
            net.eval()
            with torch.no_grad():
                vp = net(Xt[va_idx]).clamp(0, CAP)
                vloss = float((sw[va_idx] * (vp - yt[va_idx]).abs()).mean())
            if vloss < best["val"] - 1e-3:
                best = {"val": vloss, "state": {k: v.clone() for k, v in net.state_dict().items()}, "ep": ep}; bad = 0
            else:
                bad += 1
            if ep % 10 == 0 or ep == EPOCHS - 1:
                print(f"[enc] epoch {ep:3d}  train-wL1 {tot/max(nb,1):.2f}  val-wL1 {vloss:.2f}")
            if bad >= patience:
                print(f"[enc] early stop at epoch {ep} (best val {best['val']:.2f} @ ep {best['ep']})")
                break
        if best["state"] is not None:
            net.load_state_dict(best["state"])
        net.eval()
        # fold BN into each conv -> numpy weights
        encW = {}
        body = net.enc.body
        li = 0
        mods = list(body)
        for i in range(0, len(mods), 3):
            conv = mods[i]; bn = mods[i + 1]
            Wc = conv.weight.detach().numpy().astype(np.float64)          # (Cout,Cin,k)
            g = bn.weight.detach().numpy().astype(np.float64)
            be = bn.bias.detach().numpy().astype(np.float64)
            mu = bn.running_mean.detach().numpy().astype(np.float64)
            var = bn.running_var.detach().numpy().astype(np.float64)
            eps = bn.eps
            scale = g / np.sqrt(var + eps)
            encW[f"c{li}_w"] = Wc * scale[:, None, None]
            encW[f"c{li}_b"] = be - scale * mu
            li += 1
        self.encW = encW
        return net

    def fit(self, loader):
        hand, trk, raw, rid, ons, y = self._gather(loader)
        net = self._train_encoder(raw, y, rid)
        # equivalence: torch vs numpy embedding on a sample
        import torch
        with torch.no_grad():
            idx = np.arange(min(64, len(raw)))
            z = torch.tensor(raw[idx].astype(np.float32))
            N = z.shape[0]; zz = z.reshape(N * NCHAN, 1, z.shape[-1])
            m = zz.mean(-1, keepdim=True); sd = zz.std(-1, keepdim=True).clamp_min(1e-6)
            te = net.enc((zz - m) / sd).reshape(N, NCHAN * EMB).numpy()
        ne = _np_embed(raw[idx], self.encW)
        print(f"[enc] torch-vs-numpy embedding max|diff| = {np.abs(te - ne).max():.3e}  (want < 1e-3)")
        # numpy embeddings for ALL windows (train GBM on these -> zero drift)
        E = _np_embed(raw, self.encW)
        fused = np.concatenate([hand, E], axis=1)
        Xf = self._ema_assemble(fused, trk, rid, ons, y)
        print(f"[enc] fused feature dim = {Xf.shape[1]}  (hand {hand.shape[1]} + emb {E.shape[1]} + ema 10)")
        sw = BIN_WEIGHTS[np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)]
        rng = np.random.default_rng(33); perm = rng.permutation(len(y))
        cut = int(0.8 * len(y)); tr, ho = perm[:cut], perm[cut:]
        dg = Pipeline([("s", StandardScaler()), ("r", HistGradientBoostingRegressor(loss="absolute_error"))])
        dg.fit(Xf[tr], y[tr], r__sample_weight=sw[tr])
        c0 = _best_const(y[tr]); yh = y[ho]
        pg = np.clip(dg.predict(Xf[ho]), 0, 600); bi = np.clip(np.digitize(yh, BIN_EDGES[1:-1]), 0, 3)
        print(f"[encoder per-bin] c={c0:.1f}")
        print(f"{'bin':12s}{'GBM_MAE':>10s}{'const_MAE':>11s}{'gain':>8s}")
        for b, lab in enumerate(["[0,40)", "[40,90)", "[90,300)", "[300,600]"]):
            mk = bi == b
            if not mk.any():
                continue
            g = np.abs(pg[mk] - yh[mk]).mean(); cc = np.abs(c0 - yh[mk]).mean()
            print(f"{lab:12s}{g:>10.1f}{cc:>11.1f}{cc - g:>8.1f}")
        self.pipe = Pipeline([("s", StandardScaler()), ("r", HistGradientBoostingRegressor(loss="absolute_error"))])
        self.pipe.fit(Xf, y, r__sample_weight=sw)
        m = y < NEAR_FIT
        self.pipe_near = Pipeline([("s", StandardScaler()), ("r", HistGradientBoostingRegressor(loss="absolute_error"))])
        self.pipe_near.fit(Xf[m], y[m], r__sample_weight=sw[m])
        lab = (y < IMM_T).astype(int)
        npos = max(int(lab.sum()), 1); nneg = max(int((1 - lab).sum()), 1)
        cw = np.where(lab == 1, len(lab) / (2.0 * npos), len(lab) / (2.0 * nneg))
        self.clf = Pipeline([("s", StandardScaler()), ("c", HistGradientBoostingClassifier())])
        self.clf.fit(Xf, lab, c__sample_weight=cw)
        return self

    def predict(self, X):
        o, trk, Xr = compute(X, self.sfreq); xc = crosschan(X, self.sfreq)
        E = _np_embed(Xr, self.encW)
        rows = []
        for i in range(len(o)):
            t = trk[i]
            if self._ef is None:
                self._ef = t.copy(); self._es = t.copy()
            else:
                self._ef = A_FAST * t + (1 - A_FAST) * self._ef
                self._es = A_SLOW * t + (1 - A_SLOW) * self._es
            rows.append(np.concatenate([o[i], xc[i], E[i], self._ef, self._es]))
        R = np.array(rows)
        p_reg = np.clip(self.pipe.predict(R), 0.0, CAP)
        p_near = np.clip(self.pipe_near.predict(R), 0.0, CAP)
        p_imm = self.clf.predict_proba(R)[:, 1]
        raw = np.clip(p_imm * p_near + (1.0 - p_imm) * p_reg, 0.0, CAP)
        out = np.empty_like(raw)
        for i in range(len(raw)):
            est = raw[i] if self._cd is None else ALPHA * raw[i] + (1 - ALPHA) * max(self._cd - STEP, 0.0)
            est = min(max(est, 0.0), CAP); self._cd = est; out[i] = est
        return out


class Solver(CompetSolver):
    name = "Smooth-Encoder-NP"
    requirements = []

    def load_model(self, meta):
        mdl = SmoothEncoder(meta)
        w = meta["submission_dir"] / "weights.joblib"
        if w.exists():
            ck = joblib.load(w)
            mdl.encW = ck["encW"]; mdl.pipe = ck["pipe"]
            mdl.pipe_near = ck["pipe_near"]; mdl.clf = ck["clf"]
        elif self.train_loader is None:
            raise FileNotFoundError("Smooth-Encoder-NP needs weights.joblib; train with training=True.")
        return mdl

    def fit(self, model, loader):
        model.fit(loader)

    def save_model(self, model, path):
        joblib.dump({"encW": model.encW, "pipe": model.pipe,
                     "pipe_near": model.pipe_near, "clf": model.clf}, path / "weights.joblib")
