"""Smooth-Causal-TCN-Ens-v3-lean: v3, GBM trimmed to 1 seed for the time budget.

Identical to v3 (MACRO 40.24) except GBM_SEEDS=1. v4 showed the 3-seed GBM barely
moves the blend (80% TCN), so this should hold MACRO ~40.2 while cutting per-window
latency from ~6 ms back to ~3 ms -- safely under the server wall. This is the
submit candidate; its weights.joblib is what gets zipped.
"""
"""Smooth-Causal-TCN-Ens-v3: v2 + PER-SUBJECT BASELINE NORMALIZATION.

v3 adds one thing to v2 (MACRO 40.61, seen 38.8 / unseen 42.4): each window also
carries the deviation of its tracked-5 state signals (exponent, sigma/total,
delta/beta, alpha/total, total power) from THAT person's own first-~60s baseline
(causal running mean over the first N_BASE windows, then frozen -- available in
streaming). This strips the inter-person offset, which is what the seen/unseen
gap is made of, so it targets the unseen regime directly. USE_BASELINE=False
reproduces v2 exactly (clean ablation). Everything else is identical to v2.

--- v2 notes ---
v1 (fold 37.9) split train/holdout by recording -- leaky, since the same people
sit in train and holdout, so 37.9 was really a SEEN-subject estimate. The
leaderboard ranks on the macro-average of seen (new nights of known people) and
unseen (whole new people). v2 fixes this and squeezes:

  * SUBJECT-LEVEL split: hold out whole subjects (unseen) AND a new recording of
    training subjects (seen); report seen / unseen / macro, and tune the blend on
    the macro -- a non-leaky estimate of the ranking metric.
  * Regularization for the unseen gap: sequence AUGMENTATION (feature jitter,
    time-masking, feature-dropout; train-only) + a PER-RECORDING-NORMALIZED loss
    that matches the metric's equal-per-recording averaging.
  * sigma_flat (aperiodic-flattened spindle power per channel) added to the TCN
    input -- the near-onset signal the TempMixture gate flagged.
  * 5 TCN seeds incl an extra-long ~21 min RF seed; 3-seed GBM partner
    (output-averaged), mirroring the leaderboard's multi-GBM shape.
  * wider gated-blend grid (w_far up to 1.0; v1 pinned the edge at 0.8).

GBM input is unchanged (hand+cross+emb+ema, 179) so pure-GBM still reproduces the
banked 45.98. Inference is pure numpy (O(1)-per-window streaming experts, numpy
GBM traversal). subject_id comes from benchmark_utils.data.subject_ids; if the
loader doesn't expose it the split degenerates to record-level and v2 says so.
numpy + sklearn + joblib (+ torch only inside fit).
"""

import joblib
import numpy as np

from sklearn.ensemble import HistGradientBoostingRegressor, HistGradientBoostingClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from benchmark_utils.base_solver import CompetSolver
from benchmark_utils.data import to_numpy
try:
    from benchmark_utils.data import subject_ids as _subject_ids
except Exception:
    _subject_ids = None

BANDS = {"delta": (0.5, 4.0), "theta": (4.0, 8.0), "alpha": (8.0, 12.0),
         "sigma": (12.0, 16.0), "beta": (16.0, 30.0)}
FIT_LO, FIT_HI = 2.0, 40.0
EPS = 1e-8
CAP = 600.0
BIN_EDGES = np.array([0.0, 40.0, 90.0, 300.0, 600.0])
BIN_WEIGHTS = np.array([10.0, 5.0, 3.0, 1.0])
STEP = 5.0
A_FAST = 1.0 - 0.5 ** (1.0 / 6.0)
A_SLOW = 1.0 - 0.5 ** (1.0 / 24.0)
ALPHA = 0.4
NEAR_FIT = 90.0
IMM_T = 40.0
NCHAN = 4
ENC_CH = [16, 24, 16]; ENC_K = [7, 5, 5]; ENC_S = [2, 2, 2]; ENC_P = [3, 2, 2]
EMB = ENC_CH[-1]
EPOCHS = 120; LR = 2e-3; BATCH = 256
HID = 64; KERNEL = 3
DIL_LONG = [1, 2, 4, 8, 16, 32]            # RF 127 (~10.6 min)
DIL_XLONG = [1, 2, 4, 8, 16, 32, 64]       # RF 255 (~21 min)
DIL_SHORT = [1, 2, 4, 8]                   # RF 31  (~2.6 min)
SEED_CFGS = [(0, DIL_LONG), (1, DIL_LONG), (2, DIL_LONG), (3, DIL_XLONG), (4, DIL_SHORT)]
LN_EPS = 1e-5
TCN_EPOCHS = 240; TCN_LR = 3e-3; TCN_WD = 1e-4; TCN_DROP = 0.2
TCN_BATCH = 16; TCN_PATIENCE = 24
GBM_SEEDS = 1
W_NEAR_GRID = [0.0, 0.2, 0.4]
W_FAR_GRID = [0.5, 0.65, 0.8, 0.9, 1.0]
# augmentation (train-only)
AUG_NOISE = 0.05; AUG_SCALE = 0.05; AUG_TMASK = 0.08; AUG_FDROP = 0.05
# per-subject baseline normalization (v3)
USE_BASELINE = True
N_BASE = 12   # windows (~60 s) used to estimate each person's own baseline

_CACHE = {}


def _const(T, sf):
    key = (int(T), float(sf))
    c = _CACHE.get(key)
    if c is not None:
        return c
    T = int(T); sf = float(sf)
    hann = (0.5 - 0.5 * np.cos(2.0 * np.pi * np.arange(T) / T)).astype(np.float32)
    freqs = np.fft.rfftfreq(T, d=1.0 / sf)
    tmask = (freqs >= 1.0) & (freqs <= 40.0)
    bm = {k: ((freqs >= lo) & (freqs < hi)) for k, (lo, hi) in BANDS.items()}
    fm = (freqs >= FIT_LO) & (freqs <= FIT_HI)
    lf = np.log10(np.clip(freqs[fm], EPS, None)); lfc = lf - lf.mean()
    bb = (freqs >= 1.0) & (freqs <= 40.0)
    c = dict(hann=hann, freqs=freqs, tmask=tmask, bm=bm, fm=fm, lfc=lfc,
             lfcss=max(float((lfc ** 2).sum()), EPS), lfmean=float(lf.mean()),
             fb=freqs[tmask], bb=bb, logf=np.log10(np.clip(freqs, EPS, None)))
    _CACHE[key] = c
    return c


def _fix_channels(X, n=NCHAN):
    C = X.shape[1]
    if C == n:
        return X
    if C > n:
        return X[:, :n]
    return np.tile(X, (1, int(np.ceil(n / C)), 1))[:, :n]


def compute(X, sfreq):
    """lean hand features (B,C*20) + tracked (B,5) + channel-fixed raw (B,4,T)."""
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    c = _const(T, sfreq)
    xw = (X - X.mean(-1, keepdims=True)) * c["hann"]
    spec = np.fft.rfft(xw, axis=-1); psd = spec.real ** 2 + spec.imag ** 2
    tmask = c["tmask"]
    total = np.clip(psd[..., tmask].sum(-1), EPS, None)
    bp = {}; feats = []
    for k in BANDS:
        p = np.clip(psd[..., c["bm"][k]].sum(-1), EPS, None); bp[k] = p; feats.append(np.log(p))
    for k in BANDS:
        feats.append(bp[k] / total)
    feats.append(bp["delta"] / bp["beta"])
    feats.append((bp["delta"] + bp["theta"]) / (bp["alpha"] + bp["beta"]))
    ly = np.log10(np.clip(psd[..., c["fm"]], EPS, None)); ly_c = ly - ly.mean(-1, keepdims=True)
    slope = (ly_c * c["lfc"]).sum(-1) / c["lfcss"]
    exponent = -slope; offset = ly.mean(-1) - slope * c["lfmean"]
    feats.append(exponent); feats.append(offset)
    p_b = psd[..., tmask]; f_b = c["fb"]
    tot = np.clip(p_b.sum(-1, keepdims=True), EPS, None); pn = p_b / tot
    feats.append(-(pn * np.log(pn + EPS)).sum(-1))
    cum = np.cumsum(p_b, -1) / tot
    feats.append(f_b[np.clip((cum < 0.95).sum(-1), 0, f_b.size - 1)])
    d1 = np.diff(X, axis=-1); d2 = np.diff(d1, axis=-1)
    v0 = np.clip(X.var(-1), EPS, None); v1 = np.clip(d1.var(-1), EPS, None); v2 = np.clip(d2.var(-1), EPS, None)
    mob = np.sqrt(v1 / v0)
    feats.append(mob); feats.append(np.sqrt(v2 / v1) / np.clip(mob, EPS, None))
    Xd = X - X.mean(-1, keepdims=True); Sp = np.fft.rfft(Xd, axis=-1)
    s = np.fft.irfft(Sp * c["bb"], n=T, axis=-1)
    mu = s.mean(-1, keepdims=True); dd0 = s - mu
    sk = (dd0 ** 3).mean(-1) / ((dd0 ** 2).mean(-1) ** 1.5 + EPS)
    ll = np.abs(np.diff(s, axis=-1)).sum(-1) / (np.clip(s.std(-1), EPS, None) * T)
    feats.append(sk); feats.append(ll)
    out = np.nan_to_num(np.stack(feats, -1), nan=0.0, posinf=0.0, neginf=0.0).reshape(B, -1)
    tracked = np.stack([exponent.mean(1), (bp["sigma"] / total).mean(1),
                        np.log(bp["delta"] / bp["beta"]).mean(1),
                        (bp["alpha"] / total).mean(1), np.log(total).mean(1)], axis=1)
    tracked = np.nan_to_num(tracked, nan=0.0, posinf=0.0, neginf=0.0)
    return out, tracked, X


def sigma_flat(X, sfreq):
    """aperiodic-flattened (oscillatory) spindle power per channel, log. (B,4)."""
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    c = _const(T, sfreq); logf = c["logf"]
    xw = (X - X.mean(-1, keepdims=True)) * c["hann"]
    sp = np.fft.rfft(xw, axis=-1); psd = sp.real ** 2 + sp.imag ** 2
    ly = np.log10(np.clip(psd[..., c["fm"]], EPS, None)); ly_c = ly - ly.mean(-1, keepdims=True)
    slope = (ly_c * c["lfc"]).sum(-1) / c["lfcss"]
    exponent = -slope; offset = ly.mean(-1) - slope * c["lfmean"]
    ap = offset[..., None] - exponent[..., None] * logf[None, None, :]
    flat = np.clip(psd - 10.0 ** ap, 0.0, None)
    sf_ = np.log(flat[..., c["bm"]["sigma"]].sum(-1) + EPS)   # (B,C)
    return np.nan_to_num(sf_, nan=0.0, posinf=0.0, neginf=0.0)


CROSS_BANDS = [(0.5, 4.0), (4.0, 8.0), (8.0, 12.0), (12.0, 16.0), (1.0, 40.0)]
PAIRS = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


def crosschan(X, sfreq):
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    freqs = np.fft.rfftfreq(T, d=1.0 / float(sfreq))
    Xd = X - X.mean(-1, keepdims=True)
    Sp = np.fft.rfft(Xd, axis=-1); psd = Sp.real ** 2 + Sp.imag ** 2
    feats = []
    for lo, hi in CROSS_BANDS:
        mm = (freqs >= lo) & (freqs < hi)
        xb = np.fft.irfft(Sp * mm, n=T, axis=-1)
        xc = xb - xb.mean(-1, keepdims=True)
        xn = xc / np.clip(xc.std(-1, keepdims=True), EPS, None)
        Cmat = np.matmul(xn, xn.transpose(0, 2, 1)) / T
        cp = np.stack([Cmat[:, i, j] for i, j in PAIRS], -1)
        p = np.clip(psd[..., mm].sum(-1), EPS, None)
        feats.append(cp.mean(-1, keepdims=True))
        feats.append(Cmat[:, 1, 2:3]); feats.append(Cmat[:, 0, 3:4])
        feats.append(np.log(p[:, 1:2] / p[:, 2:3])); feats.append(np.log(p[:, 0:1] / p[:, 3:4]))
    return np.nan_to_num(np.concatenate(feats, -1), nan=0.0, posinf=0.0, neginf=0.0)


def _conv_bt(x, W, b, stride, pad):
    G, Cin, T = x.shape; Cout, _, k = W.shape
    xp = np.pad(x, ((0, 0), (0, 0), (pad, pad)))
    Tout = (xp.shape[2] - k) // stride + 1
    idx = np.arange(Tout)[:, None] * stride + np.arange(k)[None, :]
    cols = xp[:, :, idx].transpose(0, 1, 3, 2).reshape(G, Cin * k, Tout)
    out = np.einsum('oc,gct->got', W.reshape(Cout, Cin * k), cols, optimize=True)
    return out + b[None, :, None]


def _np_embed(Xb, encW, chunk=512):
    B = Xb.shape[0]; outs = []
    for s in range(0, B, chunk):
        xb = Xb[s:s + chunk]
        g = xb.reshape(-1, 1, Xb.shape[-1]).astype(np.float64)
        g = (g - g.mean(-1, keepdims=True)) / (g.std(-1, keepdims=True) + 1e-6)
        for li in range(len(ENC_CH)):
            g = np.maximum(_conv_bt(g, encW[f"c{li}_w"], encW[f"c{li}_b"], ENC_S[li], ENC_P[li]), 0.0)
        outs.append(g.mean(-1).reshape(xb.shape[0], NCHAN * EMB))
    return np.concatenate(outs, 0)


def _export_gbm(pipe):
    sc = pipe.steps[0][1]; est = pipe.steps[-1][1]
    base = float(np.ravel(est._baseline_prediction)[0]); trees = []
    for it in est._predictors:
        nd = it[0].nodes
        trees.append((nd['feature_idx'].astype(np.int32), nd['num_threshold'].astype(np.float64),
                      nd['left'].astype(np.int32), nd['right'].astype(np.int32),
                      nd['is_leaf'].astype(np.uint8), nd['value'].astype(np.float64)))
    return {"mean": sc.mean_.astype(np.float64), "scale": sc.scale_.astype(np.float64),
            "base": base, "trees": trees}


def _gbm_raw(x, G):
    xs = (x - G["mean"]) / G["scale"]; tot = G["base"]
    for (fi, th, lf, rt, leaf, val) in G["trees"]:
        n = 0
        while not leaf[n]:
            n = lf[n] if xs[fi[n]] <= th[n] else rt[n]
        tot += val[n]
    return tot


def _gbm_mean(x, Gs):
    return float(np.mean([_gbm_raw(x, G) for G in Gs]))


def _elapsed_feats(i):
    t = i * STEP
    return np.array([t, np.log1p(t)], dtype=np.float64)


def _ln_cols(M, g, b):
    mu = M.mean(0, keepdims=True); var = M.var(0, keepdims=True)
    return (M - mu) / np.sqrt(var + LN_EPS) * g[:, None] + b[:, None]


def _np_tcn_full(Fseq, W):
    dils = W["dils"]; h = np.maximum(W["in_w"] @ Fseq + W["in_b"][:, None], 0.0); T = Fseq.shape[1]
    for li, d in enumerate(dils):
        hp = np.pad(h, ((0, 0), ((KERNEL - 1) * d, 0)))
        conv = np.zeros((HID, T)); Wb = W[f"c{li}_w"]
        for j in range(KERNEL):
            conv += Wb[:, :, j] @ hp[:, j * d: j * d + T]
        conv += W[f"c{li}_b"][:, None]
        h = h + np.maximum(_ln_cols(conv, W[f"ln{li}_g"], W[f"ln{li}_b"]), 0.0)
    return np.clip((W["out_w"] @ h + W["out_b"]).ravel(), 0.0, CAP)


class _StreamTCN:
    def __init__(self, W):
        self.W = W; self.dils = W["dils"]; self.reset()

    def reset(self):
        self.bufs = [[] for _ in self.dils]

    def step(self, x):
        W = self.W; h = np.maximum(W["in_w"] @ x + W["in_b"], 0.0)
        for li, d in enumerate(self.dils):
            buf = self.bufs[li]; buf.append(h)
            need = (KERNEL - 1) * d + 1
            if len(buf) > need:
                del buf[0]
            conv = W[f"c{li}_b"].copy(); Wb = W[f"c{li}_w"]; L = len(buf)
            for j in range(KERNEL):
                lag = (KERNEL - 1 - j) * d; idx = L - 1 - lag
                if idx >= 0:
                    conv = conv + Wb[:, :, j] @ buf[idx]
            mu = conv.mean(); var = conv.var()
            z = (conv - mu) / np.sqrt(var + LN_EPS) * W[f"ln{li}_g"] + W[f"ln{li}_b"]
            h = h + np.maximum(z, 0.0)
        return min(max(float((W["out_w"] @ h + W["out_b"]).ravel()[0]), 0.0), CAP)


def _wbmae(yt, yp, rid):
    from benchmark_utils.metrics import binned_mae, group_scores
    import functools
    f = functools.partial(binned_mae, bin_edges=tuple(BIN_EDGES.tolist()), bin_weights=tuple(BIN_WEIGHTS.tolist()))
    return float(group_scores(f, yt, yp, rid).mean())


class CausalTCNEnsV2:
    def __init__(self, meta):
        self.sfreq = float(meta["sfreq"]); self.device = meta.get("device", "cpu")
        self.encW = None; self.Gregs = None; self.Gnears = None; self.Gclfs = None
        self.Ws = None; self.fmean = None; self.fstd = None; self.w_near = 0.0; self.w_far = 0.0
        self._ef = None; self._es = None; self._cd = None; self._i = 0; self._streams = None
        self._bl_sum = 0.0; self._bl_n = 0; self._bl = 0.0

    def reset_state(self):
        self._ef = None; self._es = None; self._cd = None; self._i = 0
        self._bl_sum = 0.0; self._bl_n = 0; self._bl = 0.0
        if self.Ws is not None:
            if self._streams is None:
                self._streams = [_StreamTCN(W) for W in self.Ws]
            else:
                for st in self._streams:
                    st.reset()

    def _gather(self, loader):
        hand, trk, raw, sfl, rid, sid, ons, Y = [], [], [], [], [], [], [], []
        for X, y, info in loader:
            o, t, Xr = compute(X, self.sfreq)
            hand.append(o); trk.append(t); raw.append(Xr); sfl.append(sigma_flat(Xr, self.sfreq))
            rid.append(to_numpy(info["record_id"]).reshape(-1))
            if _subject_ids is not None:
                sid.append(np.asarray(_subject_ids(info, len(to_numpy(info["record_id"]).reshape(-1)))).reshape(-1))
            else:
                sid.append(to_numpy(info["record_id"]).reshape(-1))
            ons.append(to_numpy(info["onset"]).reshape(-1)); Y.append(to_numpy(y).ravel())
        return (np.concatenate(hand), np.concatenate(trk), np.concatenate(raw), np.concatenate(sfl),
                np.concatenate(rid).astype(np.int64), np.concatenate(sid).astype(np.int64),
                np.concatenate(ons).astype(np.float64), np.concatenate(Y))

    def _subject_split(self, rid, sid, seed=33):
        """Return (train_recs, seen_recs, unseen_recs) sets of record_ids."""
        rng = np.random.default_rng(seed)
        rec_subj = {}
        for i in range(len(rid)):
            rec_subj[int(rid[i])] = int(sid[i])
        subj_recs = {}
        for r, s in rec_subj.items():
            subj_recs.setdefault(s, []).append(r)
        subjects = np.array(sorted(subj_recs)); rng.shuffle(subjects)
        n_unseen = max(1, int(0.2 * len(subjects)))
        unseen_subj = set(subjects[:n_unseen].tolist())
        unseen_recs = set(r for s in unseen_subj for r in subj_recs[s])
        seen_recs = set(); train_recs = set()
        for s in subjects[n_unseen:]:
            recs = sorted(subj_recs[s])
            if len(recs) >= 2:
                seen_recs.add(recs[rng.integers(len(recs))])
            for r in recs:
                if r not in seen_recs:
                    train_recs.add(r)
        degenerate = (len(np.unique(sid)) == len(np.unique(rid)))
        return train_recs, seen_recs, unseen_recs, degenerate

    def _train_encoder(self, raw, y, rid, seed=0):
        import torch
        import torch.nn as nn
        torch.manual_seed(seed)

        class Enc(nn.Module):
            def __init__(self):
                super().__init__(); layers = []; cin = 1
                for co, k, s, p in zip(ENC_CH, ENC_K, ENC_S, ENC_P):
                    layers += [nn.Conv1d(cin, co, k, stride=s, padding=p, bias=False), nn.BatchNorm1d(co), nn.ReLU()]; cin = co
                self.body = nn.Sequential(*layers)

            def forward(self, x):
                return self.body(x).mean(-1)

        class Net(nn.Module):
            def __init__(self):
                super().__init__(); self.enc = Enc(); self.drop = nn.Dropout(0.25)
                self.head = nn.Sequential(nn.Linear(NCHAN * EMB, 64), nn.ReLU(), nn.Dropout(0.25), nn.Linear(64, 1))

            def forward(self, x4):
                N = x4.shape[0]; z = x4.reshape(N * NCHAN, 1, x4.shape[-1])
                m = z.mean(-1, keepdim=True); sd = z.std(-1, keepdim=True).clamp_min(1e-6)
                e = self.drop(self.enc((z - m) / sd).reshape(N, NCHAN * EMB))
                return self.head(e)[:, 0]

        net = Net(); opt = torch.optim.Adam(net.parameters(), lr=LR, weight_decay=1e-4)
        Xt = torch.tensor(raw.astype(np.float32)); yt = torch.tensor(y.astype(np.float32))
        sw = torch.tensor(BIN_WEIGHTS[np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)].astype(np.float32))
        rng = np.random.default_rng(seed); urec = np.unique(rid); rng.shuffle(urec)
        nval = max(1, int(0.15 * len(urec))); valrec = set(urec[:nval].tolist())
        vmask = np.array([r in valrec for r in rid]); tr_idx = np.where(~vmask)[0]; va_idx = np.where(vmask)[0]
        best = {"val": np.inf, "state": None}; bad = 0
        for ep in range(EPOCHS):
            net.train(); perm = rng.permutation(tr_idx)
            for s in range(0, len(perm), BATCH):
                idx = perm[s:s + BATCH]; opt.zero_grad()
                loss = (sw[idx] * (net(Xt[idx]).clamp(0, CAP) - yt[idx]).abs()).mean()
                loss.backward(); opt.step()
            net.eval()
            with torch.no_grad():
                vloss = float((sw[va_idx] * (net(Xt[va_idx]).clamp(0, CAP) - yt[va_idx]).abs()).mean())
            if vloss < best["val"] - 1e-3:
                best = {"val": vloss, "state": {k: v.clone() for k, v in net.state_dict().items()}}; bad = 0
            else:
                bad += 1
            if bad >= 15:
                break
        if best["state"] is not None:
            net.load_state_dict(best["state"])
        net.eval()
        encW = {}; mods = list(net.enc.body); li = 0
        for i in range(0, len(mods), 3):
            conv = mods[i]; bn = mods[i + 1]
            Wc = conv.weight.detach().numpy().astype(np.float64)
            g = bn.weight.detach().numpy().astype(np.float64); be = bn.bias.detach().numpy().astype(np.float64)
            mu = bn.running_mean.detach().numpy().astype(np.float64); var = bn.running_var.detach().numpy().astype(np.float64)
            scale = g / np.sqrt(var + bn.eps)
            encW[f"c{li}_w"] = Wc * scale[:, None, None]; encW[f"c{li}_b"] = be - scale * mu; li += 1
        print(f"[enc] done (best val {best['val']:.2f})")
        return encW

    def _build_fused(self, hand, trk, raw, sfl, rid, ons, encW):
        E = _np_embed(raw, encW); cross = crosschan(raw, self.sfreq)
        base = np.concatenate([hand, cross, E], axis=1)
        first = {}
        for i in range(len(rid)):
            k = (int(rid[i]), round(float(ons[i]), 3)); first.setdefault(k, i)
        smap = {}; order = {}
        nfeat = trk.shape[1]
        for r in np.unique(rid):
            os_r = sorted({round(float(o), 3) for o in ons[rid == r]}); ef = es = None; prev = None; idxs = []
            bl_sum = 0.0; bl_n = 0; bl = 0.0   # causal running baseline, frozen after N_BASE
            for pos, o in enumerate(os_r):
                i = first[(int(r), o)]; idxs.append(i); t = trk[i]
                if prev is None or abs(o - (prev + STEP)) > 1e-6:
                    ef = t.copy(); es = t.copy()
                else:
                    ef = A_FAST * t + (1 - A_FAST) * ef; es = A_SLOW * t + (1 - A_SLOW) * es
                if bl_n < N_BASE:
                    bl_sum = bl_sum + t; bl_n += 1; bl = bl_sum / bl_n
                dev = (t - bl) if USE_BASELINE else np.zeros(nfeat)
                smap[(int(r), o)] = (ef.copy(), es.copy(), pos, dev.copy()); prev = o
            order[int(r)] = idxs
        # Xg cols: base | ef(5) | es(5)              (== Fast3NX 179, GBM unchanged)
        # Xt cols: base | ef(5) | es(5) | ef-es(5) | elapsed(2) | sigma_flat(4) [ | base_dev(5) ]
        Xg = np.zeros((len(rid), base.shape[1] + 10))
        xtw = base.shape[1] + 5 + 5 + 5 + 2 + NCHAN + (nfeat if USE_BASELINE else 0)
        Xt = np.zeros((len(rid), xtw))
        for i in range(len(rid)):
            ef, es, pos, dev = smap[(int(rid[i]), round(float(ons[i]), 3))]
            Xg[i] = np.concatenate([base[i], ef, es])
            parts = [base[i], ef, es, ef - es, _elapsed_feats(pos), sfl[i]]
            if USE_BASELINE:
                parts.append(dev)
            Xt[i] = np.concatenate(parts)
        return Xg, Xt, order

    def _train_gbm_heads(self, Xg, y):
        sw = BIN_WEIGHTS[np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)]
        mnear = y < NEAR_FIT
        lab = (y < IMM_T).astype(int)
        npos = max(int(lab.sum()), 1); nneg = max(int((1 - lab).sum()), 1)
        cw = np.where(lab == 1, len(lab) / (2.0 * npos), len(lab) / (2.0 * nneg))
        Gregs, Gnears, Gclfs = [], [], []
        for s in range(GBM_SEEDS):
            pr = Pipeline([("s", StandardScaler()), ("r", HistGradientBoostingRegressor(loss="absolute_error", max_iter=60, random_state=s))])
            pr.fit(Xg, y, r__sample_weight=sw); Gregs.append(_export_gbm(pr))
            nr = Pipeline([("s", StandardScaler()), ("r", HistGradientBoostingRegressor(loss="absolute_error", max_iter=60, random_state=s))])
            nr.fit(Xg[mnear], y[mnear], r__sample_weight=sw[mnear]); Gnears.append(_export_gbm(nr))
            cl = Pipeline([("s", StandardScaler()), ("c", HistGradientBoostingClassifier(max_iter=60, random_state=s))])
            cl.fit(Xg, lab, c__sample_weight=cw); Gclfs.append(_export_gbm(cl))
        chk = Xg[:150]
        d = np.abs(np.array([_gbm_raw(chk[i], Gregs[0]) for i in range(len(chk))])
                   - Pipeline([("s", StandardScaler()), ("r", HistGradientBoostingRegressor(loss="absolute_error", max_iter=60, random_state=0))]).fit(Xg, y, r__sample_weight=sw).predict(chk)).max()
        print(f"[gbm] {GBM_SEEDS} seeds/head; traversal-vs-sklearn(seed0 reg)={d:.2e}")
        return Gregs, Gnears, Gclfs

    def _gbm_parts(self, Xg):
        g = np.empty(len(Xg)); pimm = np.empty(len(Xg))
        for i in range(len(Xg)):
            p_reg = min(max(_gbm_mean(Xg[i], self.Gregs), 0.0), CAP)
            p_near = min(max(_gbm_mean(Xg[i], self.Gnears), 0.0), CAP)
            pi = float(np.mean([1.0 / (1.0 + np.exp(-_gbm_raw(Xg[i], Gc))) for Gc in self.Gclfs]))
            g[i] = min(max(pi * p_near + (1.0 - pi) * p_reg, 0.0), CAP); pimm[i] = pi
        return g, pimm

    def _train_tcn(self, Xt, y, order, fmean, fstd, seed, dils, augment):
        import torch
        import torch.nn as nn
        torch.manual_seed(seed); Fdim = Xt.shape[1]

        class ChanLN(nn.Module):
            def __init__(self, C):
                super().__init__(); self.g = nn.Parameter(torch.ones(C)); self.b = nn.Parameter(torch.zeros(C))

            def forward(self, h):
                mu = h.mean(1, keepdim=True); var = h.var(1, unbiased=False, keepdim=True)
                return (h - mu) / torch.sqrt(var + LN_EPS) * self.g[None, :, None] + self.b[None, :, None]

        class TCN(nn.Module):
            def __init__(self, F):
                super().__init__(); self.inp = nn.Conv1d(F, HID, 1)
                self.blocks = nn.ModuleList([nn.Conv1d(HID, HID, KERNEL, dilation=d) for d in dils])
                self.lns = nn.ModuleList([ChanLN(HID) for _ in dils])
                self.drop = nn.Dropout(TCN_DROP); self.out = nn.Conv1d(HID, 1, 1)

            def forward(self, x):
                h = torch.relu(self.inp(x))
                for conv, ln, d in zip(self.blocks, self.lns, dils):
                    z = conv(torch.nn.functional.pad(h, ((KERNEL - 1) * d, 0)))
                    h = h + self.drop(torch.relu(ln(z)))
                return self.out(h)[:, 0, :]

        recs = list(order.keys()); seqs = []
        for r in recs:
            idxs = order[r]
            F = ((Xt[idxs] - fmean) / fstd).T.astype(np.float32); yv = y[idxs].astype(np.float32)
            sw = BIN_WEIGHTS[np.clip(np.digitize(yv, BIN_EDGES[1:-1]), 0, 3)].astype(np.float32)
            seqs.append((F, yv, sw))
        rng = np.random.default_rng(seed); ridx = np.arange(len(seqs)); rng.shuffle(ridx)
        nval = max(1, int(0.15 * len(ridx))); va = sorted(ridx[:nval].tolist())
        tr = [i for i in range(len(seqs)) if i not in set(va)]

        def bt(ids, aug):
            Tmax = max(seqs[i][0].shape[1] for i in ids); B = len(ids)
            xb = np.zeros((B, Fdim, Tmax), np.float32); yb = np.zeros((B, Tmax), np.float32); wb = np.zeros((B, Tmax), np.float32)
            for bi, i in enumerate(ids):
                F, yv, sw = seqs[i]; L = F.shape[1]
                Fa = F.copy()
                if aug:
                    Fa = Fa * (1.0 + AUG_SCALE * rng.standard_normal())
                    Fa = Fa + AUG_NOISE * rng.standard_normal(Fa.shape).astype(np.float32)
                    if rng.random() < 0.5 and L > 10:
                        ml = max(1, int(AUG_TMASK * L)); st = rng.integers(0, L - ml + 1); Fa[:, st:st + ml] = 0.0
                    fd = rng.random(Fdim) < AUG_FDROP; Fa[fd, :] = 0.0
                xb[bi, :, :L] = Fa; yb[bi, :L] = yv; wb[bi, :L] = sw
            return torch.tensor(xb), torch.tensor(yb), torch.tensor(wb)

        def per_rec_loss(pred, yb, wb):
            # each sequence (row) contributes equally -> matches the metric's per-recording mean
            num = (wb * (pred - yb).abs()).sum(1)
            den = wb.sum(1).clamp_min(1.0)
            return (num / den).mean()

        net = TCN(Fdim); opt = torch.optim.Adam(net.parameters(), lr=TCN_LR, weight_decay=TCN_WD)
        vx, vy, vw = bt(va, False); best = {"val": np.inf, "state": None}; bad = 0
        for ep in range(TCN_EPOCHS):
            net.train(); perm = [tr[i] for i in rng.permutation(len(tr))]
            for s in range(0, len(perm), TCN_BATCH):
                ids = perm[s:s + TCN_BATCH]; xb, yb, wb = bt(ids, augment); opt.zero_grad()
                loss = per_rec_loss(net(xb).clamp(0, CAP), yb, wb)
                loss.backward(); torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step()
            net.eval()
            with torch.no_grad():
                vloss = float(per_rec_loss(net(vx).clamp(0, CAP), vy, vw))
            if vloss < best["val"] - 1e-3:
                best = {"val": vloss, "state": {k: v.clone() for k, v in net.state_dict().items()}}; bad = 0
            else:
                bad += 1
            if bad >= TCN_PATIENCE:
                break
        if best["state"] is not None:
            net.load_state_dict(best["state"])
        net.eval()
        sd = net.state_dict()
        W = {"dils": list(dils),
             "in_w": sd["inp.weight"][:, :, 0].numpy().astype(np.float64), "in_b": sd["inp.bias"].numpy().astype(np.float64),
             "out_w": sd["out.weight"][:, :, 0].numpy().astype(np.float64), "out_b": sd["out.bias"].numpy().astype(np.float64)}
        for li in range(len(dils)):
            W[f"c{li}_w"] = sd[f"blocks.{li}.weight"].numpy().astype(np.float64)
            W[f"c{li}_b"] = sd[f"blocks.{li}.bias"].numpy().astype(np.float64)
            W[f"ln{li}_g"] = sd[f"lns.{li}.g"].numpy().astype(np.float64)
            W[f"ln{li}_b"] = sd[f"lns.{li}.b"].numpy().astype(np.float64)
        with torch.no_grad():
            i0 = tr[0]; Fseq = (Xt[order[recs[i0]]] - fmean) / fstd
            tp = net(torch.tensor(Fseq.T[None].astype(np.float32))).clamp(0, CAP)[0].numpy()
            df = float(np.abs(tp - _np_tcn_full(Fseq.T.astype(np.float64), W)).max())
        rf = 1 + sum((KERNEL - 1) * d for d in dils)
        print(f"  [tcn s{seed} RF{rf}] best val {best['val']:.2f}  torch-vs-np {df:.1e}")
        return W

    def _train_ensemble(self, Xt, y, order, fmean, fstd, augment=True):
        return [self._train_tcn(Xt, y, order, fmean, fstd, seed, dils, augment) for seed, dils in SEED_CFGS]

    def _ens_pred_rec(self, Xt, idxs, fmean, fstd, Ws):
        Fseq = (Xt[idxs] - fmean) / fstd; acc = np.zeros(len(idxs))
        for W in Ws:
            acc += _np_tcn_full(Fseq.T.astype(np.float64), W)
        return acc / len(Ws)

    def fit(self, loader):
        hand, trk, raw, sfl, rid, sid, ons, y = self._gather(loader)
        train_recs, seen_recs, unseen_recs, degen = self._subject_split(rid, sid)
        nsub = len(np.unique(sid))
        print(f"[split] {nsub} subjects, {len(np.unique(rid))} recordings -> "
              f"train {len(train_recs)} / seen-eval {len(seen_recs)} / unseen-eval {len(unseen_recs)} recs"
              + ("   (WARNING: subject_id not exposed -> record-level, seen-eval will be empty)" if degen else ""))
        tr_mask = np.array([int(r) in train_recs for r in rid])
        seen_mask = np.array([int(r) in seen_recs for r in rid])
        unseen_mask = np.array([int(r) in unseen_recs for r in rid])
        tr_i = np.where(tr_mask)[0]
        encW_f = self._train_encoder(raw[tr_i], y[tr_i], rid[tr_i], seed=0)
        Xg, Xt, order = self._build_fused(hand, trk, raw, sfl, rid, ons, encW_f)
        self.Gregs, self.Gnears, self.Gclfs = self._train_gbm_heads(Xg[tr_i], y[tr_i])
        fmean = Xt[tr_i].mean(0); fstd = Xt[tr_i].std(0) + 1e-6
        order_tr = {r: [i for i in v if tr_mask[i]] for r, v in order.items()}; order_tr = {r: v for r, v in order_tr.items() if v}
        print(f"[ens] training {len(SEED_CFGS)} seeds (fold, augment=on) ...")
        Ws_f = self._train_ensemble(Xt, y, order_tr, fmean, fstd, augment=True)

        def eval_regime(mask):
            order_e = {r: [i for i in v if mask[i]] for r, v in order.items()}; order_e = {r: v for r, v in order_e.items() if v}
            if not order_e:
                return None
            flat = [i for v in order_e.values() for i in v]
            g, pimm = self._gbm_parts(Xg[flat])
            g_lut = {idx: float(g[k]) for k, idx in enumerate(flat)}; pi_lut = {idx: float(pimm[k]) for k, idx in enumerate(flat)}
            t_lut = {}
            for r, idxs in order_e.items():
                tp = self._ens_pred_rec(Xt, idxs, fmean, fstd, Ws_f)
                for k, idx in enumerate(idxs):
                    t_lut[idx] = float(tp[k])
            yf = np.array([y[i] for i in flat]); rf = np.array([rid[i] for i in flat])
            return order_e, g_lut, pi_lut, t_lut, yf, rf

        E_seen = eval_regime(seen_mask); E_unseen = eval_regime(unseen_mask)

        def score(E, wn, wf):
            order_e, g_lut, pi_lut, t_lut, yf, rf = E
            preds = np.empty(sum(len(v) for v in order_e.values())); p = 0
            for r, idxs in order_e.items():
                cd = None
                for i in idxs:
                    pi = pi_lut[i]; w = wf * (1 - pi) + wn * pi
                    raw_ = min(max(w * t_lut[i] + (1 - w) * g_lut[i], 0.0), CAP)
                    est = raw_ if cd is None else ALPHA * raw_ + (1 - ALPHA) * max(cd - STEP, 0.0)
                    est = min(max(est, 0.0), CAP); cd = est; preds[p] = est; p += 1
            return _wbmae(yf, preds, rf)

        print("[blend] gated grid -> seen / unseen / MACRO (tuning on macro):")
        best = (0.0, 0.0, np.inf, None, None)
        for wn in W_NEAR_GRID:
            for wf in W_FAR_GRID:
                if wn > wf:
                    continue
                s_seen = score(E_seen, wn, wf) if E_seen else float("nan")
                s_uns = score(E_unseen, wn, wf) if E_unseen else float("nan")
                macro = np.nanmean([s_seen, s_uns])
                tag = ""
                if macro < best[2]:
                    best = (wn, wf, macro, s_seen, s_uns); tag = "  <-- best"
                print(f"   wn={wn:.2f} wf={wf:.2f}   seen {s_seen:6.2f}  unseen {s_uns:6.2f}  MACRO {macro:6.2f}{tag}")
        self.w_near, self.w_far, macro, s_seen, s_uns = best
        print(f"[blend] chosen wn={self.w_near:.2f} wf={self.w_far:.2f} | seen {s_seen:.2f}  unseen {s_uns:.2f}  MACRO {macro:.2f}")
        print(f"[blend] (v1 record-level fold was 37.9 ~ seen regime; MACRO is the honest ranking estimate)")
        # ---- final on ALL data ----
        print("[final] retraining encoder + GBM + ensemble on ALL recordings ...")
        self.encW = self._train_encoder(raw, y, rid, seed=0)
        Xg2, Xt2, order2 = self._build_fused(hand, trk, raw, sfl, rid, ons, self.encW)
        self.Gregs, self.Gnears, self.Gclfs = self._train_gbm_heads(Xg2, y)
        self.fmean = Xt2.mean(0); self.fstd = Xt2.std(0) + 1e-6
        self.Ws = self._train_ensemble(Xt2, y, order2, self.fmean, self.fstd, augment=True)
        print(f"[final] done. seeds={len(self.Ws)} gbm_seeds={GBM_SEEDS} wn={self.w_near:.2f} wf={self.w_far:.2f} tcn_in={Xt2.shape[1]}")
        return self

    def predict(self, X):
        o, trk, Xr = compute(X, self.sfreq)
        E = _np_embed(Xr, self.encW); xc = crosschan(Xr, self.sfreq); sfl = sigma_flat(Xr, self.sfreq)
        out = np.empty(len(o))
        for i in range(len(o)):
            t = trk[i]
            if self._ef is None:
                self._ef = t.copy(); self._es = t.copy()
            else:
                self._ef = A_FAST * t + (1 - A_FAST) * self._ef; self._es = A_SLOW * t + (1 - A_SLOW) * self._es
            if self._bl_n < N_BASE:
                self._bl_sum = self._bl_sum + t; self._bl_n += 1; self._bl = self._bl_sum / self._bl_n
            base = np.concatenate([o[i], xc[i], E[i], self._ef, self._es])
            p_reg = min(max(_gbm_mean(base, self.Gregs), 0.0), CAP)
            p_near = min(max(_gbm_mean(base, self.Gnears), 0.0), CAP)
            p_imm = float(np.mean([1.0 / (1.0 + np.exp(-_gbm_raw(base, Gc))) for Gc in self.Gclfs]))
            gbm = min(max(p_imm * p_near + (1.0 - p_imm) * p_reg, 0.0), CAP)
            xt_parts = [base, self._ef - self._es, _elapsed_feats(self._i), sfl[i]]
            if USE_BASELINE:
                xt_parts.append(t - self._bl)
            xt = (np.concatenate(xt_parts) - self.fmean) / self.fstd
            if self._streams:
                tcn = float(np.mean([st.step(xt) for st in self._streams]))
                w = self.w_far * (1.0 - p_imm) + self.w_near * p_imm
                raw = w * tcn + (1.0 - w) * gbm
            else:
                raw = gbm
            raw = min(max(raw, 0.0), CAP)
            est = raw if self._cd is None else ALPHA * raw + (1 - ALPHA) * max(self._cd - STEP, 0.0)
            est = min(max(est, 0.0), CAP); self._cd = est; self._i += 1; out[i] = est
        return out


class Solver(CompetSolver):
    name = "Smooth-Causal-TCN-Ens-v3-lean"
    requirements = []

    def load_model(self, meta):
        mdl = CausalTCNEnsV2(meta)
        w = meta["submission_dir"] / "weights.joblib"
        if w.exists():
            ck = joblib.load(w)
            mdl.encW = ck["encW"]; mdl.Gregs = ck["Gregs"]; mdl.Gnears = ck["Gnears"]; mdl.Gclfs = ck["Gclfs"]
            mdl.Ws = ck["Ws"]; mdl.fmean = ck["fmean"]; mdl.fstd = ck["fstd"]
            mdl.w_near = ck["w_near"]; mdl.w_far = ck["w_far"]
        elif self.train_loader is None:
            raise FileNotFoundError("Smooth-Causal-TCN-Ens-v2 needs weights.joblib; train with training=True.")
        return mdl

    def fit(self, model, loader):
        model.fit(loader)

    def save_model(self, model, path):
        joblib.dump({"encW": model.encW, "Gregs": model.Gregs, "Gnears": model.Gnears, "Gclfs": model.Gclfs,
                     "Ws": model.Ws, "fmean": model.fmean, "fstd": model.fstd,
                     "w_near": model.w_near, "w_far": model.w_far}, path / "weights.joblib")
