"""Smooth-Lean (numpy): FFT-light spectral/aperiodic + Hjorth + 1 broadband
shape feature + EMA smoothing + countdown. Faithful numpy port of the torch
smooth_lean (local 48.81), so it clears the B=1 streaming time budget with no
torch per-window dispatch, and is channel-count robust. Self-contained,
submittable. numpy + sklearn + joblib + benchmark_utils only. No torch.
"""

import joblib
import numpy as np

from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from benchmark_utils.base_solver import CompetSolver
from benchmark_utils.data import to_numpy

BANDS = {"delta": (0.5, 4.0), "theta": (4.0, 8.0), "alpha": (8.0, 12.0),
         "sigma": (12.0, 16.0), "beta": (16.0, 30.0)}
FIT_LO, FIT_HI = 2.0, 40.0
EPS = 1e-8
CAP = 600.0
BIN_EDGES = np.array([0.0, 40.0, 90.0, 300.0, 600.0])
BIN_WEIGHTS = np.array([10.0, 5.0, 3.0, 1.0])
STEP = 5.0
A_FAST = 1.0 - 0.5 ** (1.0 / 6.0)
A_SLOW = 1.0 - 0.5 ** (1.0 / 24.0)
ALPHA = 0.4
NCHAN = 4

_CACHE = {}


def _const(T, sf):
    key = (int(T), float(sf))
    c = _CACHE.get(key)
    if c is not None:
        return c
    T = int(T); sf = float(sf)
    n = np.arange(T)
    hann = (0.5 - 0.5 * np.cos(2.0 * np.pi * n / T)).astype(np.float32)  # periodic
    freqs = np.fft.rfftfreq(T, d=1.0 / sf)
    tmask = (freqs >= 1.0) & (freqs <= 40.0)
    bm = {k: ((freqs >= lo) & (freqs < hi)) for k, (lo, hi) in BANDS.items()}
    fm = (freqs >= FIT_LO) & (freqs <= FIT_HI)
    lf = np.log10(np.clip(freqs[fm], EPS, None))
    lfc = lf - lf.mean()
    bb = (freqs >= 1.0) & (freqs <= 40.0)   # broadband for the shape feature
    c = dict(hann=hann, freqs=freqs, tmask=tmask, bm=bm, fm=fm, lfc=lfc,
             lfcss=max(float((lfc ** 2).sum()), EPS), lfmean=float(lf.mean()),
             fb=freqs[tmask], bb=bb)
    _CACHE[key] = c
    return c


def _fix_channels(X, n=NCHAN):
    C = X.shape[1]
    if C == n:
        return X
    if C > n:
        return X[:, :n]
    reps = int(np.ceil(n / C))
    return np.tile(X, (1, reps, 1))[:, :n]


def compute(X, sfreq):
    if hasattr(X, "detach"):
        X = X.detach().cpu().numpy()
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        X = X[None]
    X = _fix_channels(X)
    B, C, T = X.shape
    c = _const(T, sfreq)
    freqs = c["freqs"]
    xw = (X - X.mean(-1, keepdims=True)) * c["hann"]
    spec = np.fft.rfft(xw, axis=-1)
    psd = spec.real ** 2 + spec.imag ** 2

    feats = []
    tmask = c["tmask"]
    total = np.clip(psd[..., tmask].sum(-1), EPS, None)
    bp = {}
    for name in BANDS:
        p = np.clip(psd[..., c["bm"][name]].sum(-1), EPS, None)
        bp[name] = p
        feats.append(np.log(p))
    for name in BANDS:
        feats.append(bp[name] / total)
    feats.append(bp["delta"] / bp["beta"])
    feats.append((bp["delta"] + bp["theta"]) / (bp["alpha"] + bp["beta"]))

    ly = np.log10(np.clip(psd[..., c["fm"]], EPS, None))
    ly_c = ly - ly.mean(-1, keepdims=True)
    slope = (ly_c * c["lfc"]).sum(-1) / c["lfcss"]
    exponent = -slope
    offset = ly.mean(-1) - slope * c["lfmean"]
    feats.append(exponent); feats.append(offset)

    p_b = psd[..., tmask]; f_b = c["fb"]
    tot = np.clip(p_b.sum(-1, keepdims=True), EPS, None); pn = p_b / tot
    feats.append(-(pn * np.log(pn + EPS)).sum(-1))
    cum = np.cumsum(p_b, -1) / tot
    feats.append(f_b[np.clip((cum < 0.95).sum(-1), 0, f_b.size - 1)])

    d1 = np.diff(X, axis=-1); d2 = np.diff(d1, axis=-1)
    v0 = np.clip(X.var(-1), EPS, None); v1 = np.clip(d1.var(-1), EPS, None); v2 = np.clip(d2.var(-1), EPS, None)
    mob = np.sqrt(v1 / v0)
    feats.append(mob); feats.append(np.sqrt(v2 / v1) / np.clip(mob, EPS, None))

    Xd = X - X.mean(-1, keepdims=True)
    Sp = np.fft.rfft(Xd, axis=-1)
    s = np.fft.irfft(Sp * c["bb"], n=T, axis=-1)
    mu = s.mean(-1, keepdims=True); dd0 = s - mu
    sk = (dd0 ** 3).mean(-1) / ((dd0 ** 2).mean(-1) ** 1.5 + EPS)
    ll = np.abs(np.diff(s, axis=-1)).sum(-1) / (np.clip(s.std(-1), EPS, None) * T)
    feats.append(sk); feats.append(ll)

    out = np.stack(feats, -1)
    out = np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0).reshape(B, -1)

    tracked = np.stack([exponent.mean(1), (bp["sigma"] / total).mean(1),
                        np.log(bp["delta"] / bp["beta"]).mean(1),
                        (bp["alpha"] / total).mean(1), np.log(total).mean(1)], axis=1)
    tracked = np.nan_to_num(tracked, nan=0.0, posinf=0.0, neginf=0.0)
    return out, tracked


def _best_const(y):
    gr = np.arange(0.0, 600.01, 2.0)
    idx = np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)
    ne = [b for b in range(4) if np.any(idx == b)]
    s = [(BIN_WEIGHTS[ne] * np.array([np.abs(c - y)[idx == b].mean() for b in ne])).sum()
         / BIN_WEIGHTS[ne].sum() for c in gr]
    return float(gr[int(np.argmin(s))])


class LeanCD:
    def __init__(self, meta, pipe=None):
        self.sfreq = float(meta["sfreq"]); self.device = meta.get("device", "cpu"); self.pipe = pipe
        self._ef = None; self._es = None; self._cd = None

    def reset_state(self):
        self._ef = None; self._es = None; self._cd = None

    def _assemble(self, loader):
        f, trk, rid, ons, Y = [], [], [], [], []
        for X, y, info in loader:
            o, t = compute(X, self.sfreq)
            f.append(o); trk.append(t)
            rid.append(to_numpy(info["record_id"]).reshape(-1))
            ons.append(to_numpy(info["onset"]).reshape(-1)); Y.append(to_numpy(y).ravel())
        f = np.concatenate(f); trk = np.concatenate(trk)
        rid = np.concatenate(rid).astype(np.int64); ons = np.concatenate(ons).astype(np.float64)
        y = np.concatenate(Y)
        first = {}
        for i in range(len(y)):
            k = (int(rid[i]), round(float(ons[i]), 3))
            if k not in first:
                first[k] = i
        smap = {}
        for r in np.unique(rid):
            os_r = sorted({round(float(o), 3) for o in ons[rid == r]})   # ascending = forward time
            ef = es = None; prev = None
            for o in os_r:
                t = trk[first[(int(r), o)]]
                if prev is None or abs(o - (prev + STEP)) > 1e-6:
                    ef = t.copy(); es = t.copy()
                else:
                    ef = A_FAST * t + (1 - A_FAST) * ef
                    es = A_SLOW * t + (1 - A_SLOW) * es
                smap[(int(r), o)] = np.concatenate([ef, es]); prev = o
        S = np.stack([smap[(int(rid[i]), round(float(ons[i]), 3))] for i in range(len(y))])
        return np.concatenate([f, S], axis=1), y

    def fit(self, loader):
        Xf, y = self._assemble(loader)
        sw = BIN_WEIGHTS[np.clip(np.digitize(y, BIN_EDGES[1:-1]), 0, 3)]
        rng = np.random.default_rng(33); idx = rng.permutation(len(y))
        cut = int(0.8 * len(y)); tr, ho = idx[:cut], idx[cut:]
        dg = Pipeline([("s", StandardScaler()), ("r", HistGradientBoostingRegressor(loss="absolute_error"))])
        dg.fit(Xf[tr], y[tr], r__sample_weight=sw[tr])
        c = _best_const(y[tr]); yh = y[ho]
        pg = np.clip(dg.predict(Xf[ho]), 0, 600); bi = np.clip(np.digitize(yh, BIN_EDGES[1:-1]), 0, 3)
        print(f"[lean-np per-bin] c={c:.1f}  n_features={Xf.shape[1]}")
        for b, lab in enumerate(["[0,40)", "[40,90)", "[90,300)", "[300,600]"]):
            mk = bi == b
            if mk.any():
                print(f"{lab:12s} GBM {np.abs(pg[mk]-yh[mk]).mean():6.1f}  const {np.abs(c-yh[mk]).mean():6.1f}")
        self.pipe = Pipeline([("scaler", StandardScaler()),
                              ("reg", HistGradientBoostingRegressor(loss="absolute_error"))])
        self.pipe.fit(Xf, y, reg__sample_weight=sw)
        return self

    def predict(self, X):
        o, trk = compute(X, self.sfreq)
        rows = []
        for i in range(len(o)):
            t = trk[i]
            if self._ef is None:
                self._ef = t.copy(); self._es = t.copy()
            else:
                self._ef = A_FAST * t + (1 - A_FAST) * self._ef
                self._es = A_SLOW * t + (1 - A_SLOW) * self._es
            rows.append(np.concatenate([o[i], self._ef, self._es]))
        raw = np.clip(self.pipe.predict(np.array(rows)), 0.0, CAP)
        out = np.empty_like(raw)
        for i in range(len(raw)):
            est = raw[i] if self._cd is None else ALPHA * raw[i] + (1 - ALPHA) * max(self._cd - STEP, 0.0)
            est = min(max(est, 0.0), CAP); self._cd = est; out[i] = est
        return out


class Solver(CompetSolver):
    name = "Smooth-Lean-NP"
    requirements = []

    def load_model(self, meta):
        mdl = LeanCD(meta)
        w = meta["submission_dir"] / "weights.joblib"
        if w.exists():
            mdl.pipe = joblib.load(w)
        elif self.train_loader is None:
            raise FileNotFoundError("Smooth-Lean-NP needs weights.joblib; train with training=True.")
        return mdl

    def fit(self, model, loader):
        model.fit(loader)

    def save_model(self, model, path):
        joblib.dump(model.pipe, path / "weights.joblib")
